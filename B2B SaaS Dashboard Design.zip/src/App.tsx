import { useState, useEffect, useCallback } from 'react';
import {
  LayoutDashboard, Package, Archive, ShoppingCart, Users, BarChart2,
  Bell, Settings, Search, ChevronDown, TrendingUp, TrendingDown,
  Plus, Edit2, Trash2, Eye, Download, Check,
  ChevronRight, RefreshCw, LogOut, Command, X,
  Package2, Boxes, RotateCcw, CheckCircle2, XCircle, Clock,
  ArrowUpRight, Shield, Globe, User, Terminal, Headphones, Watch, Smartphone,
  Monitor, Keyboard, Mouse, Cpu, MapPin, Mail, Phone, Star,
  AlertCircle, Activity, Layers, Radio, Server, Database,
  FileBarChart, SendHorizonal, Truck, BadgeCheck, Ban,
  SlidersHorizontal, UserPlus, Filter, MoreHorizontal,
  ShoppingBag, Wallet, Target, Flame, Zap
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  Legend, RadialBarChart, RadialBar, PieChart, Pie, Cell
} from 'recharts';

type Screen = 'dashboard' | 'products' | 'inventory' | 'orders' | 'customers' | 'analytics' | 'notifications' | 'settings';

// ── Data ────────────────────────────────────────────────────────────────────
const salesData = [
  { month: 'Apr', sales: 145000, orders: 210, revenue: 132000 },
  { month: 'May', sales: 178000, orders: 256, revenue: 165000 },
  { month: 'Jun', sales: 162000, orders: 231, revenue: 148000 },
  { month: 'Jul', sales: 195000, orders: 298, revenue: 182000 },
  { month: 'Aug', sales: 221000, orders: 334, revenue: 208000 },
  { month: 'Sep', sales: 245000, orders: 356, revenue: 231000 },
];

const weeklyData = [
  { day: 'Mon', gmv: 32000, returns: 3 },
  { day: 'Tue', gmv: 41000, returns: 5 },
  { day: 'Wed', gmv: 38000, returns: 2 },
  { day: 'Thu', gmv: 54000, returns: 7 },
  { day: 'Fri', gmv: 67000, returns: 4 },
  { day: 'Sat', gmv: 89000, returns: 6 },
  { day: 'Sun', gmv: 72000, returns: 3 },
];

const categoryBreakdown = [
  { name: 'Electronics', value: 52, color: '#6366F1' },
  { name: 'Accessories', value: 28, color: '#10B981' },
  { name: 'Peripherals', value: 20, color: '#F59E0B' },
];

const productPerfData = [
  { name: 'Wireless Earbuds', sales: 48, revenue: 72000 },
  { name: 'Smart Watch', sales: 35, revenue: 87500 },
  { name: 'Phone Case', sales: 89, revenue: 22250 },
  { name: 'Laptop Stand', sales: 27, revenue: 40500 },
  { name: 'USB-C Hub', sales: 62, revenue: 55800 },
];

const sparkSales  = [32, 45, 38, 52, 61, 58, 72, 68, 81, 79, 88, 95];
const sparkOrders = [18, 22, 19, 28, 31, 27, 35, 34, 42, 39, 44, 48];
const sparkRev    = [88, 91, 87, 95, 99, 96, 103, 108, 112, 118, 122, 131];
const sparkAlert  = [1,  3,  2,  5,  3,  4,  2,   6,   4,   3,   5,   3];

const products = [
  { id: 1, name: 'Wireless Earbuds Pro', category: 'Electronics', price: 2499, status: 'Active', sku: 'WEP-001', sold: 48, rating: 4.7 },
  { id: 2, name: 'Smart Watch Series 3', category: 'Electronics', price: 8999, status: 'Active', sku: 'SWS-003', sold: 35, rating: 4.5 },
  { id: 3, name: 'Silicone Phone Case', category: 'Accessories', price: 399, status: 'Active', sku: 'SPC-112', sold: 89, rating: 4.2 },
  { id: 4, name: 'Aluminium Laptop Stand', category: 'Accessories', price: 2199, status: 'Inactive', sku: 'ALS-045', sold: 27, rating: 4.6 },
  { id: 5, name: '7-Port USB-C Hub', category: 'Electronics', price: 1799, status: 'Active', sku: 'UCH-007', sold: 62, rating: 4.3 },
  { id: 6, name: 'Mechanical Keyboard', category: 'Peripherals', price: 5499, status: 'Active', sku: 'MKB-220', sold: 41, rating: 4.8 },
  { id: 7, name: 'Gaming Mouse Pad XL', category: 'Peripherals', price: 799, status: 'Inactive', sku: 'GMP-088', sold: 22, rating: 4.1 },
];

const inventory = [
  { id: 1, name: 'Wireless Earbuds Pro', sku: 'WEP-001', qty: 3,  max: 100, threshold: 10, status: 'Low Stock',    lastRestock: '5 days ago' },
  { id: 2, name: 'Smart Watch Series 3', sku: 'SWS-003', qty: 24, max: 50,  threshold: 5,  status: 'In Stock',     lastRestock: '2 days ago' },
  { id: 3, name: 'Silicone Phone Case',  sku: 'SPC-112', qty: 0,  max: 200, threshold: 20, status: 'Out of Stock', lastRestock: '12 days ago' },
  { id: 4, name: 'Aluminium Laptop Stand', sku: 'ALS-045', qty: 67, max: 80, threshold: 15, status: 'In Stock',    lastRestock: '1 day ago' },
  { id: 5, name: '7-Port USB-C Hub',    sku: 'UCH-007', qty: 8,  max: 60,  threshold: 10, status: 'Low Stock',    lastRestock: '8 days ago' },
  { id: 6, name: 'Mechanical Keyboard', sku: 'MKB-220', qty: 41, max: 60,  threshold: 8,  status: 'In Stock',     lastRestock: '3 days ago' },
  { id: 7, name: 'Gaming Mouse Pad XL', sku: 'GMP-088', qty: 2,  max: 80,  threshold: 12, status: 'Low Stock',    lastRestock: '14 days ago' },
];

const orders = [
  { id: 'ORD12345', customer: 'Priya Sharma',  initials: 'PS', avatar: '#6366F1', date: '20 Sep 2026', value: 14997, status: 'Processing', items: 3, city: 'Mumbai' },
  { id: 'ORD12344', customer: 'Rahul Mehta',   initials: 'RM', avatar: '#10B981', date: '19 Sep 2026', value: 8999,  status: 'Shipped',    items: 1, city: 'Delhi' },
  { id: 'ORD12343', customer: 'Anita Joshi',   initials: 'AJ', avatar: '#F59E0B', date: '19 Sep 2026', value: 3298,  status: 'Delivered',  items: 2, city: 'Pune' },
  { id: 'ORD12342', customer: 'Vikram Nair',   initials: 'VN', avatar: '#8B5CF6', date: '18 Sep 2026', value: 5499,  status: 'New',        items: 1, city: 'Kochi' },
  { id: 'ORD12341', customer: 'Sunita Reddy',  initials: 'SR', avatar: '#EF4444', date: '18 Sep 2026', value: 799,   status: 'Cancelled',  items: 1, city: 'Hyderabad' },
  { id: 'ORD12340', customer: 'Amir Khan',     initials: 'AK', avatar: '#3B82F6', date: '17 Sep 2026', value: 22497, status: 'Delivered',  items: 4, city: 'Lucknow' },
  { id: 'ORD12339', customer: 'Meera Pillai',  initials: 'MP', avatar: '#EC4899', date: '17 Sep 2026', value: 1799,  status: 'Shipped',    items: 1, city: 'Chennai' },
  { id: 'ORD12338', customer: 'Deepak Gupta',  initials: 'DG', avatar: '#14B8A6', date: '16 Sep 2026', value: 9798,  status: 'Processing', items: 2, city: 'Jaipur' },
];

const customers = [
  { id: 1, name: 'Priya Sharma',  initials: 'PS', color: '#6366F1', email: 'priya.sharma@gmail.com', phone: '+91 98765 43210', location: 'Mumbai, MH', orders: 14, spend: 84000,  status: 'Active',   joined: 'Jan 2025', tier: 'Gold' },
  { id: 2, name: 'Rahul Mehta',   initials: 'RM', color: '#10B981', email: 'rahul.m@outlook.com',    phone: '+91 87654 32109', location: 'Delhi, DL',  orders: 9,  spend: 52000,  status: 'Active',   joined: 'Mar 2025', tier: 'Silver' },
  { id: 3, name: 'Anita Joshi',   initials: 'AJ', color: '#F59E0B', email: 'anita.joshi@yahoo.com',  phone: '+91 76543 21098', location: 'Pune, MH',   orders: 23, spend: 138000, status: 'Active',   joined: 'Nov 2024', tier: 'Platinum' },
  { id: 4, name: 'Vikram Nair',   initials: 'VN', color: '#8B5CF6', email: 'v.nair@gmail.com',       phone: '+91 65432 10987', location: 'Kochi, KL',  orders: 3,  spend: 11000,  status: 'Inactive', joined: 'Jun 2025', tier: 'Bronze' },
  { id: 5, name: 'Sunita Reddy',  initials: 'SR', color: '#EF4444', email: 'sunita.r@corp.in',       phone: '+91 54321 09876', location: 'Hyderabad, TS', orders: 6, spend: 27000, status: 'Active',  joined: 'May 2025', tier: 'Silver' },
  { id: 6, name: 'Amir Khan',     initials: 'AK', color: '#3B82F6', email: 'amir.khan@webmail.com',  phone: '+91 43210 98765', location: 'Lucknow, UP', orders: 31, spend: 204000, status: 'Active',  joined: 'Sep 2024', tier: 'Platinum' },
  { id: 7, name: 'Meera Pillai',  initials: 'MP', color: '#EC4899', email: 'meera.p@gmail.com',      phone: '+91 32109 87654', location: 'Chennai, TN', orders: 7,  spend: 32000,  status: 'Active',  joined: 'Apr 2025', tier: 'Silver' },
];

const notifications = [
  { id: 1, service: 'Inventory Service', serviceTag: 'inventory', priority: 'Critical',
    title: 'Stock below reorder level — Wireless Earbuds Pro',
    detail: 'Current qty: 3 / Reorder threshold: 10 units. Estimated stockout in 2 days at current velocity.',
    time: '2 min ago', read: false, action: 'Restock Now', actionIcon: <Package size={12} /> },
  { id: 2, service: 'Orders Service', serviceTag: 'orders', priority: 'Info',
    title: 'New Order #ORD12345 received',
    detail: 'Customer: Priya Sharma — ₹14,997 • 3 items • Mumbai, MH. Payment verified via Razorpay.',
    time: '5 min ago', read: false, action: 'View Order', actionIcon: <Eye size={12} /> },
  { id: 3, service: 'Inventory Service', serviceTag: 'inventory', priority: 'High',
    title: 'Stock below reorder level — Gaming Mouse Pad XL',
    detail: 'Current qty: 2 / Reorder threshold: 12 units. Last restocked 14 days ago.',
    time: '18 min ago', read: false, action: 'Restock Now', actionIcon: <Package size={12} /> },
  { id: 4, service: 'Analytics Engine', serviceTag: 'analytics', priority: 'Info',
    title: 'Weekly Sales Report Generated',
    detail: 'Report period: 13 Sep – 19 Sep 2026 • GMV: ₹3,93,000 • +18.4% vs prior week. Download ready.',
    time: '1 hr ago', read: true, action: 'Download', actionIcon: <Download size={12} /> },
  { id: 5, service: 'Orders Service', serviceTag: 'orders', priority: 'Info',
    title: 'Order #ORD12344 marked as Shipped',
    detail: 'Tracking ID: DTDC-9928834 • Carrier: DTDC • Est. delivery: 22 Sep 2026.',
    time: '2 hr ago', read: true, action: 'Track Order', actionIcon: <Truck size={12} /> },
  { id: 6, service: 'System Service', serviceTag: 'system', priority: 'Info',
    title: 'API Gateway — All endpoints healthy',
    detail: 'Avg response: 142ms P95 • Uptime: 99.98% • 0 errors in last 60 min.',
    time: '3 hr ago', read: true, action: 'View Logs', actionIcon: <Server size={12} /> },
  { id: 7, service: 'Inventory Service', serviceTag: 'inventory', priority: 'High',
    title: '7-Port USB-C Hub approaching reorder threshold',
    detail: 'Current qty: 8 / Threshold: 10 — at current sell rate, will hit threshold in ~36 hrs.',
    time: '4 hr ago', read: true, action: 'Restock Now', actionIcon: <Package size={12} /> },
  { id: 8, service: 'System Service', serviceTag: 'system', priority: 'Info',
    title: 'Scheduled DB maintenance completed',
    detail: 'Database compaction finished in 4m 22s. No downtime recorded. Next: 4 Oct 2026.',
    time: '6 hr ago', read: true, action: 'Mark Resolved', actionIcon: <Check size={12} /> },
];

// ── Utilities ─────────────────────────────────────────────────────────────────
function Sparkline({ data, color }: { data: number[]; color: string }) {
  const max = Math.max(...data), min = Math.min(...data);
  const w = 80, h = 32;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / (max - min || 1)) * (h - 6) - 3;
    return `${x},${y}`;
  });
  const fill = `${pts.join(' ')} ${w},${h} 0,${h}`;
  return (
    <svg width={w} height={h} className="overflow-visible" style={{ filter: `drop-shadow(0 0 4px ${color}80)` }}>
      <defs>
        <linearGradient id={`sg${color.replace('#','')}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity={0.4} />
          <stop offset="100%" stopColor={color} stopOpacity={0} />
        </linearGradient>
      </defs>
      <polygon points={fill} fill={`url(#sg${color.replace('#','')})`} />
      <polyline points={pts.join(' ')} fill="none" stroke={color} strokeWidth={1.5} strokeLinejoin="round" />
    </svg>
  );
}

function StatusPill({ status }: { status: string }) {
  const cfg: Record<string, { dot: string; bg: string; text: string }> = {
    'In Stock':     { dot: 'bg-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/25', text: 'text-emerald-400' },
    'Low Stock':    { dot: 'bg-amber-400',   bg: 'bg-amber-500/10 border-amber-500/25',   text: 'text-amber-400' },
    'Out of Stock': { dot: 'bg-red-400',     bg: 'bg-red-500/10 border-red-500/25',       text: 'text-red-400' },
    'Active':       { dot: 'bg-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/25', text: 'text-emerald-400' },
    'Inactive':     { dot: 'bg-slate-500',   bg: 'bg-slate-500/10 border-slate-500/25',   text: 'text-slate-400' },
    'New':          { dot: 'bg-indigo-400',  bg: 'bg-indigo-500/10 border-indigo-500/25', text: 'text-indigo-400' },
    'Processing':   { dot: 'bg-amber-400',   bg: 'bg-amber-500/10 border-amber-500/25',   text: 'text-amber-400' },
    'Shipped':      { dot: 'bg-blue-400',    bg: 'bg-blue-500/10 border-blue-500/25',     text: 'text-blue-400' },
    'Delivered':    { dot: 'bg-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/25', text: 'text-emerald-400' },
    'Cancelled':    { dot: 'bg-red-400',     bg: 'bg-red-500/10 border-red-500/25',       text: 'text-red-400' },
    'Critical':     { dot: 'bg-red-400',     bg: 'bg-red-500/12 border-red-500/30',       text: 'text-red-400' },
    'High':         { dot: 'bg-amber-400',   bg: 'bg-amber-500/10 border-amber-500/25',   text: 'text-amber-400' },
    'Info':         { dot: 'bg-indigo-400',  bg: 'bg-indigo-500/10 border-indigo-500/25', text: 'text-indigo-400' },
    'Connected':    { dot: 'bg-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/25', text: 'text-emerald-400' },
    'Disconnected': { dot: 'bg-slate-500',   bg: 'bg-slate-500/10 border-slate-500/25',   text: 'text-slate-400' },
  };
  const s = cfg[status] || cfg['Inactive'];
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold border ${s.bg} ${s.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${s.dot}`} />
      {status}
    </span>
  );
}

function serviceStyle(tag: string) {
  const map: Record<string, { color: string; border: string; bg: string; icon: React.ReactNode; label: string }> = {
    inventory: { color: 'text-red-400',    border: 'border-l-red-500',    bg: 'bg-red-500/5',    icon: <Database size={13} />,     label: 'Inventory Service' },
    orders:    { color: 'text-emerald-400',border: 'border-l-emerald-500', bg: 'bg-emerald-500/5',icon: <ShoppingBag size={13} />,  label: 'Orders Service' },
    analytics: { color: 'text-blue-400',   border: 'border-l-blue-500',   bg: 'bg-blue-500/5',   icon: <FileBarChart size={13} />, label: 'Analytics Engine' },
    system:    { color: 'text-purple-400', border: 'border-l-purple-500', bg: 'bg-purple-500/5', icon: <Server size={13} />,       label: 'System Service' },
  };
  return map[tag] || map['system'];
}

const DarkTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: 'rgba(15,20,35,0.95)', border: '1px solid rgba(99,102,241,0.3)', borderRadius: 12, padding: '10px 14px', boxShadow: '0 0 20px rgba(99,102,241,0.2)' }}>
      <p style={{ fontSize: 10, color: '#64748B', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>{label}</p>
      {payload.map((p: any) => (
        <div key={p.dataKey} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: p.color, display: 'inline-block' }} />
          <span style={{ fontSize: 11, color: '#94A3B8' }}>{p.name}: </span>
          <span style={{ fontSize: 11, color: '#fff', fontWeight: 700 }}>
            {typeof p.value === 'number' && p.value > 5000 ? `₹${p.value.toLocaleString('en-IN')}` : p.value}
          </span>
        </div>
      ))}
    </div>
  );
};

// ── Logo SVG ──────────────────────────────────────────────────────────────────
function MarketNestLogo({ size = 32 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="lg1" x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse">
          <stop stopColor="#6366F1" />
          <stop offset="1" stopColor="#8B5CF6" />
        </linearGradient>
        <linearGradient id="lg2" x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse">
          <stop stopColor="#10B981" />
          <stop offset="1" stopColor="#6366F1" />
        </linearGradient>
      </defs>
      {/* Hexagon base */}
      <path d="M20 2 L36 11 L36 29 L20 38 L4 29 L4 11 Z" fill="url(#lg1)" opacity="0.15" />
      <path d="M20 2 L36 11 L36 29 L20 38 L4 29 L4 11 Z" stroke="url(#lg1)" strokeWidth="1.5" fill="none" />
      {/* M letter stylised */}
      <path d="M11 27 L11 15 L20 23 L29 15 L29 27" stroke="url(#lg2)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      {/* Top dot accent */}
      <circle cx="20" cy="12" r="2.5" fill="url(#lg2)" />
    </svg>
  );
}

// ── Product Category Icons ────────────────────────────────────────────────────
function ProductIcon({ category, name }: { category: string; name: string }) {
  const icon = name.includes('Earbuds') ? <Headphones size={16} />
    : name.includes('Watch') ? <Watch size={16} />
    : name.includes('Phone') || name.includes('Case') ? <Smartphone size={16} />
    : name.includes('Laptop') || name.includes('Stand') ? <Monitor size={16} />
    : name.includes('Hub') ? <Cpu size={16} />
    : name.includes('Keyboard') ? <Keyboard size={16} />
    : name.includes('Mouse') ? <Mouse size={16} />
    : <Package size={16} />;

  const colors: Record<string, string> = {
    Electronics:  'text-indigo-400 bg-indigo-500/15 border-indigo-500/25',
    Accessories:  'text-emerald-400 bg-emerald-500/15 border-emerald-500/25',
    Peripherals:  'text-amber-400 bg-amber-500/15 border-amber-500/25',
  };
  return (
    <div className={`w-9 h-9 rounded-xl flex items-center justify-center border ${colors[category] || colors.Electronics} flex-shrink-0`}>
      {icon}
    </div>
  );
}

// ── Rating Stars ──────────────────────────────────────────────────────────────
function Stars({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1,2,3,4,5].map(s => (
        <Star key={s} size={10}
          className={s <= Math.round(rating) ? 'text-amber-400 fill-amber-400' : 'text-slate-700 fill-slate-700'} />
      ))}
      <span className="text-[10px] text-slate-500 ml-1">{rating}</span>
    </div>
  );
}

// ── Customer Tier Badge ───────────────────────────────────────────────────────
function TierBadge({ tier }: { tier: string }) {
  const cfg: Record<string, string> = {
    Platinum: 'text-cyan-300 bg-cyan-500/10 border-cyan-500/30',
    Gold:     'text-amber-300 bg-amber-500/10 border-amber-500/30',
    Silver:   'text-slate-300 bg-slate-500/10 border-slate-500/30',
    Bronze:   'text-orange-300 bg-orange-500/10 border-orange-500/30',
  };
  return (
    <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${cfg[tier] || cfg.Bronze}`}>{tier}</span>
  );
}

// ── Order Status Icon ─────────────────────────────────────────────────────────
function OrderStatusIcon({ status }: { status: string }) {
  const map: Record<string, { icon: React.ReactNode; color: string }> = {
    New:        { icon: <Clock size={13} />,        color: 'text-indigo-400 bg-indigo-500/15' },
    Processing: { icon: <RotateCcw size={13} />,    color: 'text-amber-400 bg-amber-500/15' },
    Shipped:    { icon: <Truck size={13} />,        color: 'text-blue-400 bg-blue-500/15' },
    Delivered:  { icon: <BadgeCheck size={13} />,   color: 'text-emerald-400 bg-emerald-500/15' },
    Cancelled:  { icon: <Ban size={13} />,          color: 'text-red-400 bg-red-500/15' },
  };
  const s = map[status] || map.New;
  return (
    <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${s.color}`}>{s.icon}</div>
  );
}

// ── Shared layout helpers ─────────────────────────────────────────────────────
function GlassCard({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl ${className}`}
      style={{ background: 'rgba(30,41,59,0.55)', border: '1px solid rgba(51,65,85,0.7)', backdropFilter: 'blur(10px)', boxShadow: '0 8px 24px rgba(0,0,0,0.25)' }}>
      {children}
    </div>
  );
}

function PageHeader({ title, sub, action }: { title: string; sub: string; action?: React.ReactNode }) {
  return (
    <div className="flex items-end justify-between mb-6">
      <div>
        <h1 className="text-xl font-bold text-white">{title}</h1>
        <p className="text-sm text-slate-500 mt-0.5">{sub}</p>
      </div>
      {action}
    </div>
  );
}

function PrimaryBtn({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return (
    <button onClick={onClick} className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-white transition-all hover:opacity-90 active:scale-95"
      style={{ background: 'linear-gradient(135deg,#6366F1,#4F46E5)', boxShadow: '0 0 20px rgba(99,102,241,0.3)' }}>
      {children}
    </button>
  );
}

function GhostBtn({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return (
    <button onClick={onClick} className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium text-slate-300 hover:text-white transition-all"
      style={{ background: 'rgba(30,41,59,0.6)', border: '1px solid rgba(51,65,85,0.7)' }}>
      {children}
    </button>
  );
}

function GlassInput({ value, onChange, placeholder, icon }: { value: string; onChange: (v: string) => void; placeholder: string; icon?: React.ReactNode }) {
  return (
    <div className="relative">
      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">{icon ?? <Search size={13} />}</span>
      <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        className="w-full pl-9 pr-4 py-2.5 text-sm text-slate-300 placeholder-slate-600 rounded-xl outline-none transition-colors"
        style={{ background: 'rgba(15,20,35,0.6)', border: '1px solid rgba(51,65,85,0.7)' }} />
    </div>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function DashboardScreen({ onNav }: { onNav: (s: Screen) => void }) {
  const unread = notifications.filter(n => !n.read).length;
  const orderTotal = orders.reduce((s, o) => s + o.value, 0);

  return (
    <div className="p-6 space-y-6">
      {/* Welcome banner */}
      <div className="rounded-2xl p-6 relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, rgba(99,102,241,0.18) 0%, rgba(139,92,246,0.12) 50%, rgba(16,185,129,0.06) 100%)', border: '1px solid rgba(99,102,241,0.2)' }}>
        <div className="absolute inset-0 pointer-events-none"
          style={{ background: 'radial-gradient(ellipse 60% 80% at 90% 50%, rgba(99,102,241,0.1) 0%, transparent 70%)' }} />
        <div className="relative flex items-center justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-indigo-400 mb-2">MarketNest Seller Operations Engine</p>
            <h1 className="text-2xl font-bold text-white">Good morning, Seller 👋</h1>
            <p className="text-slate-400 text-sm mt-1">Sunday, 20 September 2026 — Live dashboard • All 6 microservices operational</p>
          </div>
          <div className="hidden xl:flex items-center gap-6">
            {[
              { label: 'GMV Today', value: '₹72,000', up: true },
              { label: 'Pending Orders', value: '4', up: false },
              { label: 'Active Listings', value: '5/7', up: true },
            ].map(s => (
              <div key={s.label} className="text-center">
                <p className="text-xs text-slate-500 mb-0.5">{s.label}</p>
                <p className={`text-lg font-bold ${s.up ? 'text-emerald-400' : 'text-amber-400'}`}>{s.value}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Metric cards */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {[
          { label: 'Total Sales', value: '₹2,45,000', sub: '+18.4%', trendUp: true, sparkData: sparkSales,  sparkColor: '#6366F1', accent: '#A5B4FC', icon: <Wallet size={16} /> },
          { label: 'Total Orders', value: '356',       sub: '+12.7%', trendUp: true, sparkData: sparkOrders, sparkColor: '#10B981', accent: '#6EE7B7', icon: <ShoppingBag size={16} /> },
          { label: 'Total Revenue', value: '₹2,31,000', sub: '+14.2%', trendUp: true, sparkData: sparkRev,  sparkColor: '#3B82F6', accent: '#93C5FD', icon: <TrendingUp size={16} /> },
          { label: 'Low Stock Alerts', value: '3 SKUs', sub: '↑2 new', trendUp: false, sparkData: sparkAlert, sparkColor: '#EF4444', accent: '#FCA5A5', icon: <AlertCircle size={16} /> },
        ].map(m => (
          <GlassCard key={m.label} className="p-5 flex flex-col gap-3 hover:border-indigo-500/30 transition-all group cursor-default">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-1.5 mb-1">
                  <span style={{ color: m.sparkColor }}>{m.icon}</span>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500">{m.label}</p>
                </div>
                <p className="text-2xl font-black" style={{ color: m.accent }}>{m.value}</p>
              </div>
              <Sparkline data={m.sparkData} color={m.sparkColor} />
            </div>
            <div className={`flex items-center gap-1.5 text-xs font-semibold ${m.trendUp ? 'text-emerald-400' : 'text-red-400'}`}>
              {m.trendUp ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
              <span>{m.sub}</span>
              <span className="text-slate-600 font-normal">vs last month</span>
            </div>
          </GlassCard>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Sales Area Chart */}
        <GlassCard className="xl:col-span-2 p-5">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="text-sm font-bold text-white">Sales & Revenue Trends</h2>
              <p className="text-xs text-slate-500 mt-0.5">6-month rolling view · Apr – Sep 2026</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs px-3 py-1 rounded-full font-semibold text-indigo-400 border border-indigo-500/30 bg-indigo-500/10">₹2.45L</span>
              <span className="text-xs text-emerald-400 font-semibold">↑18.4%</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={210}>
            <AreaChart data={salesData} margin={{ right: 8 }}>
              <defs>
                <linearGradient id="gS" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366F1" stopOpacity={0.45} />
                  <stop offset="95%" stopColor="#6366F1" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gR" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10B981" stopOpacity={0.35} />
                  <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(51,65,85,0.45)" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#475569' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#475569' }} axisLine={false} tickLine={false} tickFormatter={v => `₹${(v/1000).toFixed(0)}k`} />
              <Tooltip content={<DarkTooltip />} />
              <Legend iconType="circle" iconSize={7} wrapperStyle={{ fontSize: 11, color: '#64748B' }} />
              <Area type="monotone" dataKey="sales"   name="Sales"   stroke="#6366F1" strokeWidth={2} fill="url(#gS)" dot={false} activeDot={{ r: 4 }} />
              <Area type="monotone" dataKey="revenue" name="Revenue" stroke="#10B981" strokeWidth={2} fill="url(#gR)" dot={false} activeDot={{ r: 4 }} />
            </AreaChart>
          </ResponsiveContainer>
        </GlassCard>

        {/* Live Alerts feed */}
        <GlassCard className="p-5 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" style={{ boxShadow: '0 0 8px rgba(239,68,68,0.8)' }} />
              <h2 className="text-sm font-bold text-white">Live Event Feed</h2>
            </div>
            <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-red-500/15 text-red-400 border border-red-500/25">{unread} NEW</span>
          </div>
          <div className="space-y-2.5 flex-1 overflow-y-auto scrollbar-hide">
            {notifications.filter(n => !n.read).map(n => {
              const ss = serviceStyle(n.serviceTag);
              return (
                <div key={n.id} className={`p-3 rounded-xl border-l-2 ${ss.border} relative overflow-hidden`}
                  style={{ background: 'rgba(15,20,35,0.5)', border: '1px solid rgba(51,65,85,0.5)' }}>
                  <div className="flex items-start gap-2">
                    <span className={`mt-0.5 flex-shrink-0 ${ss.color}`}>{ss.icon}</span>
                    <div className="min-w-0">
                      <p className={`text-[9px] font-black uppercase tracking-widest ${ss.color} mb-0.5`}>{n.service}</p>
                      <p className="text-xs text-slate-300 leading-snug">{n.title}</p>
                      <p className="text-[10px] text-slate-600 mt-1">{n.time}</p>
                    </div>
                    <StatusPill status={n.priority} />
                  </div>
                </div>
              );
            })}
            {/* Older alerts */}
            {notifications.filter(n => n.read).slice(0,2).map(n => {
              const ss = serviceStyle(n.serviceTag);
              return (
                <div key={n.id} className="p-3 rounded-xl opacity-50"
                  style={{ background: 'rgba(15,20,35,0.3)', border: '1px solid rgba(51,65,85,0.3)' }}>
                  <div className="flex items-center gap-2">
                    <span className={`flex-shrink-0 ${ss.color}`}>{ss.icon}</span>
                    <p className="text-xs text-slate-400 leading-snug truncate">{n.title}</p>
                  </div>
                  <p className="text-[10px] text-slate-600 mt-1 pl-5">{n.time}</p>
                </div>
              );
            })}
          </div>
          <button onClick={() => onNav('notifications')}
            className="mt-4 flex items-center justify-center gap-1.5 w-full py-2 rounded-xl text-xs font-semibold text-indigo-400 border border-indigo-500/20 bg-indigo-500/5 hover:bg-indigo-500/10 transition-colors">
            View all in Notification Hub <ChevronRight size={12} />
          </button>
        </GlassCard>
      </div>

      {/* Weekly GMV + Category split */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <GlassCard className="xl:col-span-2 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-white">Weekly GMV by Day</h2>
              <p className="text-xs text-slate-500 mt-0.5">14 Sep – 20 Sep 2026</p>
            </div>
            <span className="text-xs text-emerald-400 font-semibold bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">₹3,93,000 total</span>
          </div>
          <ResponsiveContainer width="100%" height={170}>
            <BarChart data={weeklyData} barCategoryGap="30%">
              <defs>
                <linearGradient id="bG" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366F1" />
                  <stop offset="100%" stopColor="#4F46E5" />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(51,65,85,0.4)" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#475569' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#475569' }} axisLine={false} tickLine={false} tickFormatter={v => `₹${(v/1000).toFixed(0)}k`} />
              <Tooltip content={<DarkTooltip />} />
              <Bar dataKey="gmv" name="GMV" fill="url(#bG)" radius={[6,6,0,0]} style={{ filter: 'drop-shadow(0 0 4px rgba(99,102,241,0.4))' }} />
            </BarChart>
          </ResponsiveContainer>
        </GlassCard>

        <GlassCard className="p-5">
          <h2 className="text-sm font-bold text-white mb-1">Category Split</h2>
          <p className="text-xs text-slate-500 mb-4">Revenue by category</p>
          <div className="flex justify-center mb-4">
            <ResponsiveContainer width={140} height={140}>
              <PieChart>
                <Pie data={categoryBreakdown} cx="50%" cy="50%" innerRadius={42} outerRadius={62} dataKey="value" strokeWidth={0}>
                  {categoryBreakdown.map((c, i) => <Cell key={i} fill={c.color} style={{ filter: `drop-shadow(0 0 4px ${c.color}80)` }} />)}
                </Pie>
                <Tooltip content={<DarkTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-2">
            {categoryBreakdown.map(c => (
              <div key={c.name} className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ background: c.color }} />
                <span className="text-xs text-slate-400 flex-1">{c.name}</span>
                <span className="text-xs font-bold text-white">{c.value}%</span>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
}

// ─── PRODUCTS ─────────────────────────────────────────────────────────────────
function ProductsScreen() {
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState('All');
  const cats = ['All', 'Electronics', 'Accessories', 'Peripherals'];
  const catColors: Record<string,string> = { Electronics:'text-indigo-400', Accessories:'text-emerald-400', Peripherals:'text-amber-400' };
  const filtered = products.filter(p =>
    (cat === 'All' || p.category === cat) && p.name.toLowerCase().includes(search.toLowerCase())
  );
  const activeCount = products.filter(p => p.status === 'Active').length;

  return (
    <div className="p-6">
      <PageHeader title="Product Catalog" sub={`${products.length} total · ${activeCount} active listings`}
        action={<PrimaryBtn><Plus size={14} /> Add New Product</PrimaryBtn>} />

      {/* Mini stats strip */}
      <div className="grid grid-cols-3 gap-3 mb-5">
        {[
          { label: 'Electronics', count: products.filter(p=>p.category==='Electronics').length, color:'#6366F1', icon: <Cpu size={14}/> },
          { label: 'Accessories', count: products.filter(p=>p.category==='Accessories').length, color:'#10B981', icon: <Package size={14}/> },
          { label: 'Peripherals', count: products.filter(p=>p.category==='Peripherals').length, color:'#F59E0B', icon: <Mouse size={14}/> },
        ].map(s => (
          <GlassCard key={s.label} className="flex items-center gap-3 px-4 py-3">
            <span style={{ color: s.color }}>{s.icon}</span>
            <span className="text-xs text-slate-400">{s.label}</span>
            <span className="ml-auto text-sm font-bold text-white">{s.count}</span>
          </GlassCard>
        ))}
      </div>

      <GlassCard>
        <div className="p-4 border-b border-slate-700/50 flex flex-wrap items-center gap-3">
          <div className="flex-1 min-w-48"><GlassInput value={search} onChange={setSearch} placeholder="Search by name, SKU..." /></div>
          <div className="flex gap-1.5 flex-wrap">
            {cats.map(c => (
              <button key={c} onClick={() => setCat(c)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${cat === c ? 'text-white' : 'text-slate-400 hover:text-slate-200'}`}
                style={cat === c ? { background: 'linear-gradient(135deg,#6366F1,#4F46E5)', boxShadow: '0 0 12px rgba(99,102,241,0.3)' } : { background: 'rgba(30,41,59,0.5)', border: '1px solid rgba(51,65,85,0.5)' }}>
                {c}
              </button>
            ))}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-700/40">
                {['Product', 'SKU', 'Category', 'Price', 'Sold', 'Rating', 'Status', ''].map(h => (
                  <th key={h} className="text-left px-4 py-3.5 text-[10px] font-black text-slate-500 uppercase tracking-widest">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((p, i) => (
                <tr key={p.id}
                  className={`border-b border-slate-800/40 transition-all cursor-pointer ${i === filtered.length-1 ? 'border-0' : ''}`}
                  style={{ background: 'transparent' }}
                  onMouseEnter={e => (e.currentTarget.style.background = 'rgba(99,102,241,0.05)')}
                  onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                  <td className="px-4 py-3.5">
                    <div className="flex items-center gap-3">
                      <ProductIcon category={p.category} name={p.name} />
                      <span className="font-semibold text-slate-200 text-sm">{p.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3.5 font-mono text-xs text-indigo-400">{p.sku}</td>
                  <td className="px-4 py-3.5">
                    <span className={`text-xs font-semibold ${catColors[p.category]}`}>{p.category}</span>
                  </td>
                  <td className="px-4 py-3.5 font-black text-slate-200">₹{p.price.toLocaleString('en-IN')}</td>
                  <td className="px-4 py-3.5">
                    <span className="text-slate-400 text-xs">{p.sold} units</span>
                  </td>
                  <td className="px-4 py-3.5"><Stars rating={p.rating} /></td>
                  <td className="px-4 py-3.5"><StatusPill status={p.status} /></td>
                  <td className="px-4 py-3.5">
                    <div className="flex items-center gap-1">
                      <button className="p-2 rounded-lg transition-colors text-slate-500 hover:text-indigo-400"
                        style={{ background: 'rgba(99,102,241,0.08)' }}><Edit2 size={12} /></button>
                      <button className="p-2 rounded-lg transition-colors text-slate-500 hover:text-red-400"
                        style={{ background: 'rgba(239,68,68,0.08)' }}><Trash2 size={12} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && <div className="py-16 text-center text-sm text-slate-600">No products found.</div>}
        </div>
      </GlassCard>
    </div>
  );
}

// ─── INVENTORY ────────────────────────────────────────────────────────────────
function InventoryScreen() {
  const [filter, setFilter] = useState('All Items');
  const pills = ['All Items', 'Low Stock (3)', 'Out of Stock (1)'];
  const filtered = inventory.filter(i => {
    if (filter === 'Low Stock (3)')   return i.status === 'Low Stock';
    if (filter === 'Out of Stock (1)')return i.status === 'Out of Stock';
    return true;
  });

  function pct(qty: number, max: number) { return Math.min(100, Math.round((qty / max) * 100)); }

  const stockSummary = [
    { label: 'In Stock', count: inventory.filter(i => i.status === 'In Stock').length, color: '#10B981' },
    { label: 'Low Stock', count: inventory.filter(i => i.status === 'Low Stock').length, color: '#F59E0B' },
    { label: 'Out of Stock', count: inventory.filter(i => i.status === 'Out of Stock').length, color: '#EF4444' },
  ];

  return (
    <div className="p-6">
      <PageHeader title="Inventory Monitoring" sub="Real-time stock levels across all SKUs"
        action={<GhostBtn><RefreshCw size={13} /> Sync Stock</GhostBtn>} />

      <div className="grid grid-cols-3 gap-3 mb-5">
        {stockSummary.map(s => (
          <GlassCard key={s.label} className="flex items-center gap-3 px-4 py-3.5">
            <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: s.color, boxShadow: `0 0 8px ${s.color}` }} />
            <span className="text-sm text-slate-400">{s.label}</span>
            <span className="ml-auto text-xl font-black" style={{ color: s.color }}>{s.count}</span>
          </GlassCard>
        ))}
      </div>

      <div className="flex gap-2 mb-5 flex-wrap">
        {pills.map(p => (
          <button key={p} onClick={() => setFilter(p)}
            className={`px-4 py-2 rounded-full text-xs font-bold transition-all ${filter === p ? 'text-white' : 'text-slate-400 hover:text-slate-200'}`}
            style={filter === p ? { background: 'linear-gradient(135deg,#6366F1,#4F46E5)', boxShadow: '0 0 14px rgba(99,102,241,0.35)' } : { background: 'rgba(30,41,59,0.5)', border: '1px solid rgba(51,65,85,0.6)' }}>
            {p}
          </button>
        ))}
      </div>

      <GlassCard>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-700/40">
              {['Product', 'SKU', 'Stock Level', 'Capacity', 'Threshold', 'Last Restock', 'Status', 'Action'].map(h => (
                <th key={h} className="text-left px-4 py-3.5 text-[10px] font-black text-slate-500 uppercase tracking-widest">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((item, i) => {
              const p = pct(item.qty, item.max);
              const barColor = item.status === 'Out of Stock' ? '#EF4444' : item.status === 'Low Stock' ? '#F59E0B' : '#10B981';
              return (
                <tr key={item.id}
                  className={`border-b border-slate-800/40 transition-all ${i === filtered.length-1 ? 'border-0' : ''}`}
                  style={{ background: 'transparent' }}
                  onMouseEnter={e => (e.currentTarget.style.background = 'rgba(99,102,241,0.04)')}
                  onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                  <td className="px-4 py-4 font-semibold text-slate-200">{item.name}</td>
                  <td className="px-4 py-4 font-mono text-xs text-indigo-400">{item.sku}</td>
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-3 min-w-32">
                      <span className="text-sm font-black tabular-nums w-8" style={{ color: barColor }}>{item.qty}</span>
                      <div className="flex-1 h-2 rounded-full overflow-hidden" style={{ background: 'rgba(51,65,85,0.6)' }}>
                        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${p}%`, background: barColor, boxShadow: `0 0 6px ${barColor}80` }} />
                      </div>
                      <span className="text-[10px] text-slate-600 w-8">{p}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-4 text-slate-500 text-xs">{item.max} max</td>
                  <td className="px-4 py-4">
                    <span className="text-xs font-semibold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
                      ≥ {item.threshold}
                    </span>
                  </td>
                  <td className="px-4 py-4 text-slate-500 text-xs">{item.lastRestock}</td>
                  <td className="px-4 py-4"><StatusPill status={item.status} /></td>
                  <td className="px-4 py-4">
                    <button className="text-xs px-3 py-1.5 rounded-xl font-semibold transition-all text-indigo-400 hover:text-white hover:opacity-90"
                      style={{ background: 'linear-gradient(135deg, rgba(99,102,241,0.15), rgba(79,70,229,0.15))', border: '1px solid rgba(99,102,241,0.25)' }}>
                      Restock
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </GlassCard>
    </div>
  );
}

// ─── ORDERS ───────────────────────────────────────────────────────────────────
function OrdersScreen() {
  const tabs = ['All', 'New', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];
  const [tab, setTab] = useState('All');
  const filtered = orders.filter(o => tab === 'All' || o.status === tab);
  const totalValue = filtered.reduce((s, o) => s + o.value, 0);

  const tabIcons: Record<string, React.ReactNode> = {
    New: <Clock size={11} />, Processing: <RotateCcw size={11} />,
    Shipped: <Truck size={11} />, Delivered: <BadgeCheck size={11} />, Cancelled: <Ban size={11} />,
  };

  return (
    <div className="p-6">
      <PageHeader title="Order Execution" sub={`${orders.length} total orders · ₹${orders.reduce((s,o)=>s+o.value,0).toLocaleString('en-IN')} GMV`}
        action={<GhostBtn><Download size={13} /> Export</GhostBtn>} />

      {/* Tab strip */}
      <GlassCard className="overflow-hidden mb-5">
        <div className="flex overflow-x-auto scrollbar-hide">
          {tabs.map(t => {
            const cnt = t === 'All' ? orders.length : orders.filter(o => o.status === t).length;
            return (
              <button key={t} onClick={() => setTab(t)}
                className={`flex-shrink-0 flex items-center gap-1.5 px-5 py-3.5 text-xs font-bold uppercase tracking-widest border-b-2 transition-all ${tab === t ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-300'}`}>
                {tabIcons[t]}
                {t}
                <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-black ${tab === t ? 'bg-indigo-500/20 text-indigo-400' : 'bg-slate-800 text-slate-600'}`}>{cnt}</span>
              </button>
            );
          })}
          {tab !== 'All' && <div className="ml-auto flex items-center px-4 text-xs text-slate-500">
            Subtotal: <span className="text-white font-bold ml-1">₹{totalValue.toLocaleString('en-IN')}</span>
          </div>}
        </div>
      </GlassCard>

      <GlassCard>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-700/40">
              {['Order', 'Customer', 'Location', 'Items', 'Date', 'Value', 'Status', ''].map(h => (
                <th key={h} className="text-left px-4 py-3.5 text-[10px] font-black text-slate-500 uppercase tracking-widest">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((o, i) => (
              <tr key={o.id}
                className={`border-b border-slate-800/40 transition-all ${i === filtered.length-1 ? 'border-0' : ''}`}
                style={{ background: 'transparent' }}
                onMouseEnter={e => (e.currentTarget.style.background = 'rgba(99,102,241,0.04)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                <td className="px-4 py-4">
                  <div className="flex items-center gap-2">
                    <OrderStatusIcon status={o.status} />
                    <span className="font-mono text-xs font-bold text-indigo-400">{o.id}</span>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-black text-white flex-shrink-0"
                      style={{ background: o.avatar }}>
                      {o.initials}
                    </div>
                    <span className="font-semibold text-slate-200 text-sm">{o.customer}</span>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center gap-1 text-slate-500 text-xs">
                    <MapPin size={10} />{o.city}
                  </div>
                </td>
                <td className="px-4 py-4 text-slate-400 text-xs">{o.items} item{o.items > 1 ? 's' : ''}</td>
                <td className="px-4 py-4 text-slate-500 text-xs">{o.date}</td>
                <td className="px-4 py-4 font-black text-slate-200">₹{o.value.toLocaleString('en-IN')}</td>
                <td className="px-4 py-4"><StatusPill status={o.status} /></td>
                <td className="px-4 py-4">
                  <button className="p-2 rounded-lg text-slate-500 hover:text-indigo-400 transition-colors"
                    style={{ background: 'rgba(99,102,241,0.08)' }}><Eye size={13} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <div className="py-16 text-center text-sm text-slate-600">No orders in this status.</div>}
      </GlassCard>
    </div>
  );
}

// ─── CUSTOMERS ────────────────────────────────────────────────────────────────
function CustomersScreen() {
  const [search, setSearch] = useState('');
  const filtered = customers.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6">
      <PageHeader title="Customer Directory" sub={`${customers.length} registered · ${customers.filter(c=>c.status==='Active').length} active`}
        action={<PrimaryBtn><UserPlus size={14} /> Add Customer</PrimaryBtn>} />

      {/* Top customers banner */}
      <div className="grid grid-cols-3 gap-3 mb-5">
        {customers.filter(c => c.tier === 'Platinum').map(c => (
          <GlassCard key={c.id} className="flex items-center gap-3 px-4 py-3.5">
            <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-black text-white flex-shrink-0"
              style={{ background: c.color }}>
              {c.initials}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5"><p className="text-xs font-semibold text-slate-200 truncate">{c.name}</p><TierBadge tier={c.tier} /></div>
              <p className="text-[10px] text-emerald-400 font-bold">₹{c.spend.toLocaleString('en-IN')} spend</p>
            </div>
          </GlassCard>
        ))}
        <GlassCard className="flex items-center justify-center px-4 py-3.5 gap-2 cursor-pointer hover:border-indigo-500/30 transition-all">
          <Star size={14} className="text-amber-400" />
          <span className="text-xs font-semibold text-slate-400">Top Spenders</span>
        </GlassCard>
      </div>

      <GlassCard>
        <div className="p-4 border-b border-slate-700/50">
          <div className="max-w-sm"><GlassInput value={search} onChange={setSearch} placeholder="Search by name or email..." /></div>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-700/40">
              {['Customer', 'Contact', 'Location', 'Orders', 'Lifetime Spend', 'Tier', 'Status'].map(h => (
                <th key={h} className="text-left px-4 py-3.5 text-[10px] font-black text-slate-500 uppercase tracking-widest">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((c, i) => (
              <tr key={c.id}
                className={`border-b border-slate-800/40 transition-all ${i === filtered.length-1 ? 'border-0' : ''}`}
                style={{ background: 'transparent' }}
                onMouseEnter={e => (e.currentTarget.style.background = 'rgba(99,102,241,0.04)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                <td className="px-4 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-black text-white flex-shrink-0"
                      style={{ background: c.color, boxShadow: `0 0 10px ${c.color}50` }}>
                      {c.initials}
                    </div>
                    <div>
                      <p className="font-semibold text-slate-200 text-sm">{c.name}</p>
                      <p className="text-[10px] text-slate-600">Joined {c.joined}</p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-slate-500 text-xs"><Mail size={10} />{c.email}</div>
                    <div className="flex items-center gap-1.5 text-slate-500 text-xs"><Phone size={10} />{c.phone}</div>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center gap-1 text-slate-400 text-xs"><MapPin size={10} />{c.location}</div>
                </td>
                <td className="px-4 py-4 font-bold text-slate-200">{c.orders}</td>
                <td className="px-4 py-4 font-black text-emerald-400 text-sm">₹{c.spend.toLocaleString('en-IN')}</td>
                <td className="px-4 py-4"><TierBadge tier={c.tier} /></td>
                <td className="px-4 py-4"><StatusPill status={c.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <div className="py-16 text-center text-sm text-slate-600">No customers found.</div>}
      </GlassCard>
    </div>
  );
}

// ─── ANALYTICS ────────────────────────────────────────────────────────────────
function AnalyticsScreen() {
  return (
    <div className="p-6 space-y-5">
      <PageHeader title="Analytics & Reports" sub="Seller performance insights — September 2026"
        action={<PrimaryBtn><Download size={14} /> Export Report</PrimaryBtn>} />

      {/* KPI strip */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
        {[
          { label: 'Conversion Rate', value: '3.8%', sub: '+0.6%', color: '#6366F1' },
          { label: 'Avg. Order Value', value: '₹6,884', sub: '+₹412', color: '#10B981' },
          { label: 'Return Rate', value: '2.1%', sub: '-0.3%', color: '#F59E0B' },
          { label: 'Customer NPS', value: '74', sub: '+8pts', color: '#3B82F6' },
        ].map(k => (
          <GlassCard key={k.label} className="px-4 py-3.5">
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500 mb-1">{k.label}</p>
            <p className="text-xl font-black" style={{ color: k.color }}>{k.value}</p>
            <p className="text-xs text-emerald-400 font-semibold mt-0.5">{k.sub} vs last month</p>
          </GlassCard>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <GlassCard className="p-5">
          <h2 className="text-sm font-bold text-white mb-0.5">Product Performance</h2>
          <p className="text-xs text-slate-500 mb-5">Units sold — Sep 2026</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={productPerfData} layout="vertical" barCategoryGap="20%">
              <defs>
                <linearGradient id="bGH" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#6366F1" />
                  <stop offset="100%" stopColor="#8B5CF6" />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(51,65,85,0.4)" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 10, fill: '#475569' }} axisLine={false} tickLine={false} />
              <YAxis dataKey="name" type="category" tick={{ fontSize: 10, fill: '#64748B' }} axisLine={false} tickLine={false} width={110} />
              <Tooltip content={<DarkTooltip />} />
              <Bar dataKey="sales" name="Units Sold" fill="url(#bGH)" radius={[0,6,6,0]}
                style={{ filter: 'drop-shadow(0 0 5px rgba(99,102,241,0.4))' }} />
            </BarChart>
          </ResponsiveContainer>
        </GlassCard>

        <GlassCard className="p-5">
          <h2 className="text-sm font-bold text-white mb-0.5">Revenue vs Order Volume</h2>
          <p className="text-xs text-slate-500 mb-5">6-month dual-axis trend</p>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(51,65,85,0.4)" />
              <XAxis dataKey="month" tick={{ fontSize: 10, fill: '#475569' }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="l" tick={{ fontSize: 10, fill: '#475569' }} axisLine={false} tickLine={false} tickFormatter={v => `₹${(v/1000).toFixed(0)}k`} />
              <YAxis yAxisId="r" orientation="right" tick={{ fontSize: 10, fill: '#475569' }} axisLine={false} tickLine={false} />
              <Tooltip content={<DarkTooltip />} />
              <Legend iconType="circle" iconSize={7} wrapperStyle={{ fontSize: 11, color: '#64748B' }} />
              <Line yAxisId="l" type="monotone" dataKey="revenue" name="Revenue" stroke="#6366F1" strokeWidth={2.5}
                dot={{ r: 3, fill: '#6366F1', strokeWidth: 0 }} style={{ filter: 'drop-shadow(0 0 4px rgba(99,102,241,0.5))' }} />
              <Line yAxisId="r" type="monotone" dataKey="orders" name="Orders" stroke="#10B981" strokeWidth={2.5}
                dot={{ r: 3, fill: '#10B981', strokeWidth: 0 }} strokeDasharray="5 3"
                style={{ filter: 'drop-shadow(0 0 4px rgba(16,185,129,0.5))' }} />
            </LineChart>
          </ResponsiveContainer>
        </GlassCard>
      </div>

      <GlassCard className="p-5">
        <h2 className="text-sm font-bold text-white mb-4">Top Products — Revenue Leaderboard</h2>
        <div className="space-y-3">
          {[...productPerfData].sort((a,b) => b.revenue - a.revenue).map((p, i) => {
            const pct = Math.round((p.revenue / 87500) * 100);
            const colors = ['#6366F1','#10B981','#3B82F6','#F59E0B','#8B5CF6'];
            return (
              <div key={p.name} className="flex items-center gap-4 group">
                <span className="text-xs font-black text-slate-600 w-4 text-right">#{i+1}</span>
                <span className="text-sm text-slate-300 w-36 truncate font-medium">{p.name}</span>
                <div className="flex-1 h-2.5 rounded-full overflow-hidden" style={{ background: 'rgba(51,65,85,0.5)' }}>
                  <div className="h-full rounded-full transition-all duration-700"
                    style={{ width: `${pct}%`, background: colors[i], boxShadow: `0 0 8px ${colors[i]}60` }} />
                </div>
                <span className="text-xs font-black w-20 text-right" style={{ color: colors[i] }}>
                  ₹{p.revenue.toLocaleString('en-IN')}
                </span>
              </div>
            );
          })}
        </div>
      </GlassCard>
    </div>
  );
}

// ─── NOTIFICATIONS ────────────────────────────────────────────────────────────
function NotificationsScreen() {
  const [tab, setTab] = useState('All Alerts');
  const [items, setItems] = useState(notifications);
  const tabs = ['All Alerts', 'Unread', 'High Priority', 'Critical'];
  const filtered = items.filter(n => {
    if (tab === 'Unread')       return !n.read;
    if (tab === 'High Priority')return n.priority === 'High' || n.priority === 'Critical';
    if (tab === 'Critical')     return n.priority === 'Critical';
    return true;
  });
  const markRead = (id: number) => setItems(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  const markAll = () => setItems(prev => prev.map(n => ({ ...n, read: true })));

  return (
    <div className="p-6">
      <PageHeader title="Notification Hub" sub="Centralized microservice event stream — live monitoring"
        action={<GhostBtn onClick={markAll}><Check size={13} /> Mark All Read</GhostBtn>} />

      {/* Service legend */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-3 mb-5">
        {(['inventory','orders','analytics','system'] as const).map(tag => {
          const ss = serviceStyle(tag);
          const cnt = items.filter(n => n.serviceTag === tag).length;
          const unread = items.filter(n => n.serviceTag === tag && !n.read).length;
          return (
            <GlassCard key={tag} className="flex items-center gap-3 px-4 py-3.5">
              <span className={ss.color}>{ss.icon}</span>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-slate-300 truncate">{ss.label}</p>
                <p className="text-[10px] text-slate-600">{cnt} events</p>
              </div>
              {unread > 0 && <span className="text-[9px] font-black w-5 h-5 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center border border-red-500/30">{unread}</span>}
            </GlassCard>
          );
        })}
      </div>

      <GlassCard className="overflow-hidden">
        <div className="flex border-b border-slate-700/50 overflow-x-auto scrollbar-hide">
          {tabs.map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-5 py-4 text-xs font-black uppercase tracking-widest whitespace-nowrap border-b-2 transition-all ${tab === t ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-300'}`}>
              {t}
              <span className={`ml-2 text-[9px] px-1.5 py-0.5 rounded-full ${tab === t ? 'bg-indigo-500/20 text-indigo-400' : 'bg-slate-800 text-slate-600'}`}>
                {tab === t ? filtered.length : items.filter(n => t === 'Unread' ? !n.read : t === 'High Priority' ? (n.priority==='High'||n.priority==='Critical') : t === 'Critical' ? n.priority==='Critical' : true).length}
              </span>
            </button>
          ))}
        </div>

        <div className="divide-y divide-slate-800/50">
          {filtered.map(n => {
            const ss = serviceStyle(n.serviceTag);
            const isUnread = !n.read;
            return (
              <div key={n.id}
                className={`flex items-start gap-5 p-5 border-l-[3px] ${ss.border} transition-all hover:bg-slate-800/20 ${isUnread ? 'bg-indigo-500/3' : ''}`}>
                {/* Service icon */}
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${ss.color} mt-0.5`}
                  style={{ background: `${ss.bg}`, border: '1px solid rgba(148,163,184,0.15)' }}>
                  {ss.icon}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1.5">
                    <span className={`text-[9px] font-black uppercase tracking-widest ${ss.color} border rounded px-1.5 py-0.5 border-current opacity-80`}>
                      {n.service}
                    </span>
                    <StatusPill status={n.priority} />
                    {isUnread && (
                      <span className="w-2 h-2 rounded-full bg-indigo-400 flex-shrink-0"
                        style={{ boxShadow: '0 0 6px rgba(99,102,241,0.8)' }} />
                    )}
                  </div>
                  <p className={`text-sm leading-snug mb-1 ${isUnread ? 'font-bold text-white' : 'font-medium text-slate-300'}`}>{n.title}</p>
                  <p className="text-xs text-slate-500 leading-relaxed">{n.detail}</p>
                  <p className="text-[10px] text-slate-600 mt-2">{n.time}</p>
                </div>

                <div className="flex items-center gap-2 flex-shrink-0 mt-1">
                  <button className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-xl font-semibold text-indigo-400 hover:text-white transition-all"
                    style={{ background: 'linear-gradient(135deg,rgba(99,102,241,0.12),rgba(79,70,229,0.12))', border: '1px solid rgba(99,102,241,0.25)' }}>
                    {n.actionIcon}{n.action}
                  </button>
                  {isUnread && (
                    <button onClick={() => markRead(n.id)}
                      className="text-xs px-3 py-1.5 rounded-xl text-slate-500 hover:text-slate-300 transition-all"
                      style={{ background: 'rgba(30,41,59,0.5)', border: '1px solid rgba(51,65,85,0.5)' }}>
                      Dismiss
                    </button>
                  )}
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && <div className="py-16 text-center text-sm text-slate-600">No alerts in this category.</div>}
        </div>
      </GlassCard>
    </div>
  );
}

// ─── SETTINGS ─────────────────────────────────────────────────────────────────
function ToggleSwitch({ on }: { on: boolean }) {
  const [enabled, setEnabled] = useState(on);
  return (
    <button onClick={() => setEnabled(!enabled)}
      className="relative inline-flex w-11 h-6 rounded-full transition-all flex-shrink-0"
      style={enabled ? { background: 'linear-gradient(135deg,#6366F1,#4F46E5)', boxShadow: '0 0 12px rgba(99,102,241,0.4)' } : { background: 'rgba(30,41,59,0.8)', border: '1px solid rgba(51,65,85,0.6)' }}>
      <span className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-white shadow-md transition-transform ${enabled ? 'translate-x-5' : 'translate-x-0'}`} />
    </button>
  );
}

function SettingsScreen() {
  const [tab, setTab] = useState('Seller Profile');
  const tabs = ['Seller Profile', 'User Roles', 'Notification Rules', 'Integrations'];

  return (
    <div className="p-6">
      <PageHeader title="Settings" sub="Manage your store, team access, and integrations" />
      <GlassCard className="overflow-hidden">
        <div className="flex border-b border-slate-700/50 overflow-x-auto scrollbar-hide">
          {tabs.map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-6 py-4 text-xs font-black uppercase tracking-widest whitespace-nowrap border-b-2 transition-all ${tab === t ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-300'}`}>
              {t}
            </button>
          ))}
        </div>
        <div className="p-6">
          {tab === 'Seller Profile' && (
            <div className="max-w-lg space-y-5">
              {/* Avatar hero */}
              <div className="flex items-center gap-5 p-5 rounded-2xl border border-slate-700/50"
                style={{ background: 'linear-gradient(135deg,rgba(99,102,241,0.1),rgba(139,92,246,0.06))' }}>
                <div className="relative">
                  <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-black text-indigo-300"
                    style={{ background: 'linear-gradient(135deg,rgba(99,102,241,0.3),rgba(139,92,246,0.2))', border: '2px solid rgba(99,102,241,0.4)', boxShadow: '0 0 20px rgba(99,102,241,0.2)' }}>
                    S
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-400 border-2 border-slate-900"
                    style={{ boxShadow: '0 0 6px rgba(16,185,129,0.6)' }} />
                </div>
                <div>
                  <p className="font-bold text-white text-base">MarketNest Seller</p>
                  <p className="text-sm text-slate-400">seller@marketnest.com</p>
                  <p className="text-xs text-indigo-400 font-semibold mt-1">Pro Plan · Renews 1 Oct 2026</p>
                </div>
                <button className="ml-auto text-xs px-3 py-2 rounded-xl font-semibold text-slate-300 hover:text-white transition-colors"
                  style={{ background: 'rgba(30,41,59,0.7)', border: '1px solid rgba(51,65,85,0.6)' }}>
                  Change
                </button>
              </div>
              {[
                { label: 'Store Name', value: 'MarketNest Official Store', icon: <ShoppingBag size={13} /> },
                { label: 'Email Address', value: 'seller@marketnest.com', icon: <Mail size={13} /> },
                { label: 'Phone Number', value: '+91 98765 00001', icon: <Phone size={13} /> },
                { label: 'GSTIN', value: '27AAPFU0939F1ZV', icon: <Shield size={13} /> },
              ].map(f => (
                <div key={f.label}>
                  <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-widest">{f.label}</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600">{f.icon}</span>
                    <input defaultValue={f.value}
                      className="w-full pl-9 pr-4 py-3 text-sm text-slate-300 rounded-xl outline-none transition-colors"
                      style={{ background: 'rgba(15,20,35,0.6)', border: '1px solid rgba(51,65,85,0.7)' }} />
                  </div>
                </div>
              ))}
              <PrimaryBtn>Save Changes</PrimaryBtn>
            </div>
          )}

          {tab === 'User Roles' && (
            <div className="space-y-3 max-w-xl">
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm text-slate-400">Manage team members and permissions</p>
                <PrimaryBtn><Plus size={12} /> Invite Member</PrimaryBtn>
              </div>
              {[
                { name: 'Priya Sharma', email: 'priya@marketnest.com', role: 'Admin',   color: '#6366F1', status: 'Active' },
                { name: 'Rahul Mehta',  email: 'rahul@marketnest.com', role: 'Manager', color: '#10B981', status: 'Active' },
                { name: 'Anita Joshi',  email: 'anita@marketnest.com', role: 'Viewer',  color: '#F59E0B', status: 'Inactive' },
              ].map(u => (
                <div key={u.email} className="flex items-center gap-3 p-4 rounded-xl border border-slate-700/50 hover:border-slate-600/60 transition-all"
                  style={{ background: 'rgba(15,20,35,0.4)' }}>
                  <div className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-black text-white flex-shrink-0"
                    style={{ background: u.color }}>
                    {u.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-slate-200">{u.name}</p>
                    <p className="text-xs text-slate-500">{u.email}</p>
                  </div>
                  <select defaultValue={u.role}
                    className="text-xs rounded-lg px-2.5 py-1.5 text-slate-300 outline-none"
                    style={{ background: 'rgba(30,41,59,0.8)', border: '1px solid rgba(51,65,85,0.7)' }}>
                    <option>Admin</option><option>Manager</option><option>Viewer</option>
                  </select>
                  <StatusPill status={u.status} />
                </div>
              ))}
            </div>
          )}

          {tab === 'Notification Rules' && (
            <div className="space-y-3 max-w-lg">
              {[
                { label: 'Low stock alerts', desc: 'Notify when stock drops below reorder threshold', on: true, icon: <Database size={14}/> },
                { label: 'New order received', desc: 'Instant alert for every new order placed', on: true, icon: <ShoppingBag size={14}/> },
                { label: 'Order status changes', desc: 'Notify on processing, shipped, delivered updates', on: false, icon: <Truck size={14}/> },
                { label: 'Weekly sales report', desc: 'Auto-generated report every Monday 8 AM', on: true, icon: <FileBarChart size={14}/> },
                { label: 'API Gateway alerts', desc: 'Notify on latency spikes or downtime', on: false, icon: <Server size={14}/> },
                { label: 'Customer registrations', desc: 'Alert on new customer sign-ups', on: false, icon: <UserPlus size={14}/> },
              ].map(r => (
                <div key={r.label} className="flex items-center gap-4 p-4 rounded-xl border border-slate-700/50 hover:border-slate-600/60 transition-all"
                  style={{ background: 'rgba(15,20,35,0.4)' }}>
                  <span className="text-slate-500 flex-shrink-0">{r.icon}</span>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-slate-200">{r.label}</p>
                    <p className="text-xs text-slate-500 mt-0.5">{r.desc}</p>
                  </div>
                  <ToggleSwitch on={r.on} />
                </div>
              ))}
            </div>
          )}

          {tab === 'Integrations' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {[
                { name: 'Razorpay',          desc: 'Payment gateway',           status: 'Connected',    icon: '💳', ping: '98ms' },
                { name: 'Shiprocket',        desc: 'Shipping & fulfillment',    status: 'Connected',    icon: '🚚', ping: '112ms' },
                { name: 'Zoho CRM',          desc: 'Customer management',       status: 'Disconnected', icon: '👥', ping: null },
                { name: 'Google Analytics',  desc: 'Traffic & conversion',      status: 'Connected',    icon: '📊', ping: '87ms' },
                { name: 'WhatsApp Business', desc: 'Customer notifications',    status: 'Disconnected', icon: '💬', ping: null },
                { name: 'AWS S3',            desc: 'Asset & image storage',     status: 'Connected',    icon: '☁️', ping: '34ms' },
              ].map(s => (
                <div key={s.name} className="flex items-start gap-3 p-4 rounded-xl border border-slate-700/50 hover:border-slate-600/60 transition-all"
                  style={{ background: 'rgba(15,20,35,0.4)' }}>
                  <span className="text-2xl flex-shrink-0">{s.icon}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <p className="text-sm font-semibold text-slate-200">{s.name}</p>
                      <StatusPill status={s.status} />
                    </div>
                    <p className="text-xs text-slate-500">{s.desc}</p>
                    {s.ping && <p className="text-[10px] text-emerald-500 mt-0.5 font-semibold">Latency: {s.ping}</p>}
                    <button className={`mt-2.5 text-xs px-3 py-1 rounded-xl font-semibold transition-all ${s.status === 'Connected' ? 'bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20' : 'bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20 border border-indigo-500/20'}`}>
                      {s.status === 'Connected' ? 'Disconnect' : 'Connect'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </GlassCard>
    </div>
  );
}

// ── Command Palette ───────────────────────────────────────────────────────────
const cmdItems = [
  { label: 'Go to Dashboard',      screen: 'dashboard'     as Screen, icon: <LayoutDashboard size={14} />, hint: 'Overview' },
  { label: 'View Products',        screen: 'products'      as Screen, icon: <Package size={14} />,         hint: '7 products' },
  { label: 'Check Inventory',      screen: 'inventory'     as Screen, icon: <Archive size={14} />,         hint: '3 low stock' },
  { label: 'Manage Orders',        screen: 'orders'        as Screen, icon: <ShoppingCart size={14} />,    hint: '8 orders' },
  { label: 'Customer Directory',   screen: 'customers'     as Screen, icon: <Users size={14} />,           hint: '7 customers' },
  { label: 'Analytics & Reports',  screen: 'analytics'     as Screen, icon: <BarChart2 size={14} />,       hint: 'Sep 2026' },
  { label: 'Notification Hub',     screen: 'notifications' as Screen, icon: <Bell size={14} />,            hint: '3 unread' },
  { label: 'Settings',             screen: 'settings'      as Screen, icon: <Settings size={14} />,        hint: 'Config' },
];

function CommandPalette({ onClose, onNavigate }: { onClose: () => void; onNavigate: (s: Screen) => void }) {
  const [q, setQ] = useState('');
  const filtered = cmdItems.filter(i => i.label.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20"
      style={{ background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(4px)' }}
      onClick={onClose}>
      <div className="w-full max-w-lg mx-4 rounded-2xl overflow-hidden"
        style={{ background: 'rgba(15,20,35,0.98)', border: '1px solid rgba(99,102,241,0.3)', boxShadow: '0 0 60px rgba(99,102,241,0.2), 0 25px 50px rgba(0,0,0,0.7)' }}
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-700/60">
          <Search size={15} className="text-indigo-400 flex-shrink-0" />
          <input autoFocus value={q} onChange={e => setQ(e.target.value)}
            placeholder="Search orders, products, or trigger microservice actions..."
            className="flex-1 bg-transparent text-sm text-slate-200 placeholder-slate-600 outline-none" />
          <kbd className="text-[10px] text-slate-600 bg-slate-800 px-1.5 py-0.5 rounded font-mono">ESC</kbd>
        </div>
        <div className="p-2 max-h-72 overflow-y-auto">
          {filtered.map(item => (
            <button key={item.label} onClick={() => { onNavigate(item.screen); onClose(); }}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-slate-400 hover:bg-indigo-500/10 hover:text-indigo-300 transition-all group">
              <span className="text-slate-600 group-hover:text-indigo-400 transition-colors">{item.icon}</span>
              <span className="flex-1 text-left">{item.label}</span>
              <span className="text-[10px] text-slate-600 bg-slate-800/60 px-2 py-0.5 rounded-full">{item.hint}</span>
              <ArrowUpRight size={12} className="text-slate-700 group-hover:text-indigo-400 transition-colors" />
            </button>
          ))}
        </div>
        <div className="px-5 py-3 border-t border-slate-700/60 flex gap-4 text-[10px] text-slate-700">
          <span><kbd className="bg-slate-800 px-1 rounded font-mono text-slate-600">↑↓</kbd> navigate</span>
          <span><kbd className="bg-slate-800 px-1 rounded font-mono text-slate-600">↵</kbd> select</span>
          <span><kbd className="bg-slate-800 px-1 rounded font-mono text-slate-600">ESC</kbd> close</span>
        </div>
      </div>
    </div>
  );
}

// ── Toast ──────────────────────────────────────────────────────────────────────
interface Toast { id: number; msg: string; type: 'info' | 'success' | 'error' }

let toastId = 0;
const liveMessages = [
  { msg: 'Inventory Service: Wireless Earbuds Pro fell below reorder threshold (qty: 3)', type: 'error' as const },
  { msg: 'Orders Service: New order #ORD12346 confirmed — ₹6,299 from Rahul Mehta, Delhi', type: 'success' as const },
  { msg: 'Analytics Engine: Weekly performance report generated and ready to download', type: 'info' as const },
  { msg: 'System Service: API Gateway latency normalized — avg 142ms, uptime 99.98%', type: 'info' as const },
];

function ToastBanner({ toasts, onDismiss }: { toasts: Toast[]; onDismiss: (id: number) => void }) {
  const colors: Record<string, { border: string; glow: string; dot: string }> = {
    error:   { border: 'border-red-500/40',   glow: '0 0 20px rgba(239,68,68,0.15)',   dot: 'bg-red-500' },
    success: { border: 'border-emerald-500/40',glow: '0 0 20px rgba(16,185,129,0.15)', dot: 'bg-emerald-500' },
    info:    { border: 'border-indigo-500/40', glow: '0 0 20px rgba(99,102,241,0.15)', dot: 'bg-indigo-500' },
  };
  return (
    <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 pointer-events-none">
      {toasts.map(t => {
        const c = colors[t.type];
        return (
          <div key={t.id} className={`toast-enter pointer-events-auto flex items-start gap-3 px-4 py-3 rounded-xl max-w-xs border ${c.border}`}
            style={{ background: 'rgba(15,20,35,0.95)', backdropFilter: 'blur(12px)', boxShadow: c.glow }}>
            <span className={`w-2 h-2 rounded-full ${c.dot} flex-shrink-0 mt-1`} style={{ boxShadow: `0 0 6px currentColor` }} />
            <p className="text-xs text-slate-300 flex-1 leading-relaxed">{t.msg}</p>
            <button onClick={() => onDismiss(t.id)} className="text-slate-600 hover:text-slate-300 flex-shrink-0 mt-0.5"><X size={12} /></button>
          </div>
        );
      })}
    </div>
  );
}

// ── Nav items ─────────────────────────────────────────────────────────────────
const navItems: { id: Screen; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard',     label: 'Dashboard',      icon: <LayoutDashboard size={15} /> },
  { id: 'products',      label: 'Products',        icon: <Package size={15} /> },
  { id: 'inventory',     label: 'Inventory',       icon: <Boxes size={15} /> },
  { id: 'orders',        label: 'Orders',          icon: <ShoppingCart size={15} /> },
  { id: 'customers',     label: 'Customers',       icon: <Users size={15} /> },
  { id: 'analytics',     label: 'Analytics',       icon: <BarChart2 size={15} /> },
  { id: 'notifications', label: 'Notifications',   icon: <Bell size={15} /> },
  { id: 'settings',      label: 'Settings',        icon: <Settings size={15} /> },
];

// ── Seller App (existing dashboard) ──────────────────────────────────────────
function SellerApp({ onLogout }: { onLogout: () => void }) {
  const [screen, setScreen] = useState<Screen>('dashboard');
  const [cmdOpen, setCmdOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const unread = notifications.filter(n => !n.read).length;

  const addToast = useCallback((msg: string, type: Toast['type']) => {
    const id = ++toastId;
    setToasts(prev => [...prev, { id, msg, type }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 6000);
  }, []);

  useEffect(() => {
    const timers = liveMessages.map((m, i) =>
      setTimeout(() => addToast(m.msg, m.type), 3000 + i * 5000)
    );
    return () => timers.forEach(clearTimeout);
  }, [addToast]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); setCmdOpen(true); }
      if (e.key === 'Escape') { setCmdOpen(false); setNotifOpen(false); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const screenMap: Record<Screen, React.ReactNode> = {
    dashboard:     <DashboardScreen onNav={setScreen} />,
    products:      <ProductsScreen />,
    inventory:     <InventoryScreen />,
    orders:        <OrdersScreen />,
    customers:     <CustomersScreen />,
    analytics:     <AnalyticsScreen />,
    notifications: <NotificationsScreen />,
    settings:      <SettingsScreen />,
  };

  return (
    <div className="flex h-screen overflow-hidden bg-mesh font-sans">
      <ToastBanner toasts={toasts} onDismiss={id => setToasts(prev => prev.filter(t => t.id !== id))} />
      {cmdOpen && <CommandPalette onClose={() => setCmdOpen(false)} onNavigate={s => { setScreen(s); setCmdOpen(false); }} />}

      {/* Notification flyout — fixed so it escapes header stacking context */}
      {notifOpen && (
        <>
          {/* Click-outside backdrop */}
          <div className="fixed inset-0 z-40" onClick={() => setNotifOpen(false)} />
          <div className="fixed top-16 right-4 w-80 rounded-2xl overflow-hidden z-50"
            style={{ background: 'rgba(10,14,24,0.98)', border: '1px solid rgba(51,65,85,0.6)', boxShadow: '0 0 40px rgba(0,0,0,0.7), 0 0 20px rgba(99,102,241,0.1)' }}>
            <div className="px-4 py-3 border-b border-slate-700/60 flex items-center justify-between">
              <p className="text-xs font-bold text-slate-300">Recent Alerts</p>
              <button onClick={() => setNotifOpen(false)}><X size={12} className="text-slate-600 hover:text-slate-300" /></button>
            </div>
            <div className="max-h-72 overflow-y-auto divide-y divide-slate-800/60">
              {notifications.slice(0, 5).map(n => {
                const ss = serviceStyle(n.serviceTag);
                return (
                  <div key={n.id} className={`px-4 py-3 border-l-2 ${ss.border} hover:bg-slate-800/30 transition-colors`}>
                    <div className="flex gap-2">
                      <span className={`${ss.color} flex-shrink-0 mt-0.5`}>{ss.icon}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-slate-300 leading-snug line-clamp-2">{n.title}</p>
                        <p className="text-[10px] text-slate-600 mt-0.5">{n.time}</p>
                      </div>
                      {!n.read && <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 flex-shrink-0 mt-1" />}
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="px-4 py-2.5 border-t border-slate-700/60">
              <button onClick={() => { setScreen('notifications'); setNotifOpen(false); }}
                className="text-xs text-indigo-400 font-bold flex items-center gap-1 hover:text-indigo-300 transition-colors">
                Open Notification Hub <ChevronRight size={11} />
              </button>
            </div>
          </div>
        </>
      )}

      {/* ── Sidebar ── */}
      <aside className="w-56 flex-shrink-0 flex flex-col"
        style={{ background: 'rgba(8,12,20,0.97)', borderRight: '1px solid rgba(51,65,85,0.5)', backdropFilter: 'blur(20px)' }}>
        {/* Logo */}
        <div className="px-5 py-5" style={{ borderBottom: '1px solid rgba(51,65,85,0.4)' }}>
          <div className="flex items-center gap-3">
            <MarketNestLogo size={36} />
            <div>
              <p className="text-sm font-black text-white leading-tight">MarketNest</p>
              <p className="text-[9px] font-semibold tracking-[0.15em] uppercase mt-0.5"
                style={{ background: 'linear-gradient(90deg,#6366F1,#10B981)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                Seller Engine
              </p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 px-3 space-y-0.5 overflow-y-auto scrollbar-hide">
          <p className="px-2 pb-2 text-[8px] font-black text-slate-700 uppercase tracking-[0.18em]">Navigation</p>
          {navItems.map(item => {
            const active = screen === item.id;
            return (
              <button key={item.id} onClick={() => setScreen(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all group ${active ? 'text-indigo-300' : 'text-slate-500 hover:text-slate-200 hover:bg-white/4'}`}
                style={active ? { background: 'linear-gradient(135deg,rgba(99,102,241,0.2),rgba(99,102,241,0.08))', border: '1px solid rgba(99,102,241,0.25)', boxShadow: '0 0 12px rgba(99,102,241,0.15)' } : {}}>
                <span className={`flex-shrink-0 transition-colors ${active ? 'text-indigo-400' : 'text-slate-600 group-hover:text-slate-400'}`}>{item.icon}</span>
                <span>{item.label}</span>
                {item.id === 'notifications' && unread > 0 && (
                  <span className="ml-auto min-w-[18px] h-[18px] rounded-full bg-red-500 text-white text-[9px] font-black flex items-center justify-center px-1 flex-shrink-0"
                    style={{ boxShadow: '0 0 8px rgba(239,68,68,0.6)' }}>
                    {unread}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Profile */}
        <div className="p-3" style={{ borderTop: '1px solid rgba(51,65,85,0.4)' }}>
          <button onClick={onLogout} className="w-full flex items-center gap-2.5 px-2.5 py-2.5 rounded-xl hover:bg-white/5 cursor-pointer transition-all group">
            <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-black text-indigo-300 flex-shrink-0"
              style={{ background: 'linear-gradient(135deg,rgba(99,102,241,0.3),rgba(139,92,246,0.2))', border: '1px solid rgba(99,102,241,0.35)' }}>S</div>
            <div className="flex-1 min-w-0 text-left">
              <p className="text-xs font-bold text-slate-300 leading-none truncate">Seller Account</p>
              <p className="text-[9px] text-slate-600 mt-0.5 truncate">seller@marketnest.com</p>
            </div>
            <LogOut size={12} className="text-slate-700 group-hover:text-red-400 flex-shrink-0 transition-colors" />
          </button>
        </div>
      </aside>

      {/* ── Main area ── */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="flex-shrink-0 h-14 flex items-center px-5 gap-4"
          style={{ background: 'rgba(8,12,20,0.85)', borderBottom: '1px solid rgba(51,65,85,0.5)', backdropFilter: 'blur(16px)' }}>

          {/* Command palette btn */}
          <button onClick={() => setCmdOpen(true)}
            className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm text-slate-500 hover:text-slate-300 transition-all flex-1 max-w-sm"
            style={{ background: 'rgba(20,26,40,0.7)', border: '1px solid rgba(51,65,85,0.6)' }}>
            <Command size={12} className="text-indigo-400" />
            <span className="text-xs flex-1 text-left text-slate-600">Search orders, products, trigger actions...</span>
            <kbd className="text-[9px] font-mono bg-slate-900 text-slate-600 px-1.5 py-0.5 rounded hidden sm:block">⌘K</kbd>
          </button>

          <div className="ml-auto flex items-center gap-3">
            {/* Microservices health */}
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold text-emerald-400"
              style={{ background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.2)' }}>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 flex-shrink-0"
                style={{ boxShadow: '0 0 6px rgba(16,185,129,0.8)', animation: 'pulse 2s infinite' }} />
              6/6 Microservices Online
            </div>

            {/* Bell */}
            <div className="relative">
              <button onClick={() => setNotifOpen(v => !v)}
                className="relative w-9 h-9 flex items-center justify-center rounded-xl transition-all"
                style={{ background: 'rgba(20,26,40,0.7)', border: '1px solid rgba(51,65,85,0.6)' }}>
                <Bell size={15} className="text-slate-400" />
                {unread > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-red-500 text-white text-[8px] font-black flex items-center justify-center"
                    style={{ boxShadow: '0 0 8px rgba(239,68,68,0.7)' }}>
                    {unread}
                  </span>
                )}
              </button>
            </div>

            {/* Avatar */}
            <button className="flex items-center gap-2 px-2 py-1.5 rounded-xl transition-all"
              style={{ background: 'rgba(20,26,40,0.7)', border: '1px solid rgba(51,65,85,0.6)' }}>
              <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black text-indigo-300"
                style={{ background: 'linear-gradient(135deg,rgba(99,102,241,0.5),rgba(139,92,246,0.3))' }}>S</div>
              <ChevronDown size={11} className="text-slate-600" />
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto">
          {screenMap[screen]}
        </main>
      </div>
    </div>
  );
}

// LOGIN PAGE

type AuthRole = 'seller' | 'admin';

function LoginPage({ onLogin }: { onLogin: (role: AuthRole) => void }) {
  const [role, setRole] = useState<AuthRole>('seller');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [remember, setRemember] = useState(false);
  const [loading, setLoading] = useState(false);

  const defaultEmail = role === 'seller' ? 'seller@marketnest.com' : 'admin@marketnest.com';

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLogin(role);
    }, 1200);
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-mesh font-sans px-4 py-12 relative overflow-hidden">
      {/* Ambient orbs */}
      <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(99,102,241,0.12) 0%, transparent 70%)', filter: 'blur(40px)' }} />
      <div className="absolute bottom-0 right-1/4 w-80 h-80 rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(16,185,129,0.08) 0%, transparent 70%)', filter: 'blur(40px)' }} />

      {/* Card */}
      <div className="relative w-full max-w-md rounded-3xl overflow-hidden"
        style={{
          background: 'rgba(30,41,59,0.82)',
          backdropFilter: 'blur(24px)',
          WebkitBackdropFilter: 'blur(24px)',
          border: '1px solid rgba(99,102,241,0.22)',
          boxShadow: '0 0 60px rgba(99,102,241,0.12), 0 25px 50px rgba(0,0,0,0.55), inset 0 1px 0 rgba(255,255,255,0.05)',
        }}>

        {/* Top gradient strip */}
        <div className="h-0.5 w-full" style={{ background: 'linear-gradient(90deg,transparent,#6366F1,#10B981,transparent)' }} />

        <div className="px-8 pt-10 pb-8">
          {/* Logo */}
          <div className="flex flex-col items-center mb-8">
            <div className="flex items-center gap-3 mb-3">
              <MarketNestLogo size={44} />
              <div>
                <p className="text-xl font-black text-white leading-tight">MarketNest</p>
                <p className="text-[10px] font-bold tracking-[0.18em] uppercase"
                  style={{ background: 'linear-gradient(90deg,#6366F1,#10B981)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                  Smart Seller Operations Platform
                </p>
              </div>
            </div>
            <p className="text-xs text-slate-500 text-center leading-relaxed max-w-xs">
              Centralized Smart Operations &amp; SOA Management Hub
            </p>
          </div>

          {/* Role switcher */}
          <div className="flex rounded-xl p-1 mb-7"
            style={{ background: 'rgba(15,20,35,0.7)', border: '1px solid rgba(51,65,85,0.6)' }}>
            {([
              { id: 'seller' as AuthRole, label: '🛍️  Seller Portal' },
              { id: 'admin'  as AuthRole, label: '🛡️  Platform Admin' },
            ] as const).map(tab => (
              <button
                key={tab.id}
                onClick={() => { setRole(tab.id); setEmail(''); }}
                className="flex-1 py-2.5 rounded-lg text-xs font-bold transition-all"
                style={role === tab.id ? {
                  background: 'linear-gradient(135deg,#6366F1,#4F46E5)',
                  color: '#fff',
                  boxShadow: '0 0 16px rgba(99,102,241,0.4)',
                } : { color: '#64748B' }}>
                {tab.label}
              </button>
            ))}
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email */}
            <div>
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">
                Email Address
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-600">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
                  </svg>
                </span>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder={defaultEmail}
                  required
                  className="w-full pl-10 pr-4 py-3 text-sm text-slate-300 placeholder-slate-600 rounded-xl outline-none transition-all"
                  style={{ background: 'rgba(15,20,35,0.7)', border: '1px solid rgba(51,65,85,0.7)' }}
                  onFocus={e => (e.target.style.borderColor = 'rgba(99,102,241,0.5)')}
                  onBlur={e => (e.target.style.borderColor = 'rgba(51,65,85,0.7)')}
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">
                Password
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-600">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                  </svg>
                </span>
                <input
                  type={showPw ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  required
                  className="w-full pl-10 pr-11 py-3 text-sm text-slate-300 placeholder-slate-600 rounded-xl outline-none transition-all"
                  style={{ background: 'rgba(15,20,35,0.7)', border: '1px solid rgba(51,65,85,0.7)' }}
                  onFocus={e => (e.target.style.borderColor = 'rgba(99,102,241,0.5)')}
                  onBlur={e => (e.target.style.borderColor = 'rgba(51,65,85,0.7)')}
                />
                <button type="button" onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-600 hover:text-slate-400 transition-colors">
                  {showPw ? (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                      <line x1="1" y1="1" x2="23" y2="23"/>
                    </svg>
                  ) : (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
                    </svg>
                  )}
                </button>
              </div>
            </div>

            {/* Remember + Forgot */}
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer group">
                <div
                  onClick={() => setRemember(!remember)}
                  className="w-4 h-4 rounded flex items-center justify-center flex-shrink-0 transition-all"
                  style={remember ? { background: 'linear-gradient(135deg,#6366F1,#4F46E5)', boxShadow: '0 0 8px rgba(99,102,241,0.5)' } : { background: 'transparent', border: '1px solid rgba(51,65,85,0.8)' }}>
                  {remember && (
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3">
                      <polyline points="20 6 9 17 4 12"/>
                    </svg>
                  )}
                </div>
                <span className="text-xs text-slate-500 group-hover:text-slate-400 transition-colors select-none">Remember me</span>
              </label>
              <button type="button" className="text-xs text-indigo-400 hover:text-indigo-300 transition-colors font-semibold">
                Forgot Password?
              </button>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-xl text-sm font-black text-white transition-all relative overflow-hidden mt-2"
              style={{
                background: loading ? 'rgba(99,102,241,0.4)' : 'linear-gradient(135deg,#6366F1,#4F46E5)',
                boxShadow: loading ? 'none' : '0 0 24px rgba(99,102,241,0.45), 0 4px 12px rgba(0,0,0,0.3)',
              }}>
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Authenticating…
                </span>
              ) : (
                <>Sign In to {role === 'seller' ? 'Seller' : 'Admin'} Dashboard →</>
              )}
            </button>
          </form>

          {/* Role hint */}
          <div className="mt-5 px-4 py-3 rounded-xl text-center"
            style={{ background: 'rgba(15,20,35,0.5)', border: '1px solid rgba(51,65,85,0.4)' }}>
            <p className="text-[11px] text-slate-500">
              {role === 'seller'
                ? <><span className="text-indigo-400 font-semibold">Seller Portal</span> — Manage products, inventory, orders &amp; analytics</>
                : <><span className="text-emerald-400 font-semibold">Platform Admin</span> — SOA health, microservices, RBAC &amp; seller oversight</>}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-8 py-4 border-t border-slate-700/40 text-center"
          style={{ background: 'rgba(15,20,35,0.4)' }}>
          <p className="text-[10px] text-slate-600">
            🔒 Secured by Role-Based Access Control (RBAC) • API Gateway v2.4
          </p>
        </div>
      </div>

      {/* Version tag */}
      <p className="mt-6 text-[10px] text-slate-700">MarketNest Platform v3.1.0 • © 2026 MarketNest Inc.</p>
    </div>
  );
}

// ADMIN APP

type AdminScreen = 'health' | 'logs' | 'gateway' | 'sellers' | 'rbac' | 'alerts';

// ── Admin data ────────────────────────────────────────────────────────────────
const microservices = [
  { name: 'Order Service',     tag: 'orders',     status: 'Healthy',  latency: 98,  uptime: 99.97, req: 4821, version: 'v2.4.1', port: 8081 },
  { name: 'Inventory Service', tag: 'inventory',  status: 'Degraded', latency: 312, uptime: 98.21, req: 2340, version: 'v2.3.8', port: 8082 },
  { name: 'Analytics Engine',  tag: 'analytics',  status: 'Healthy',  latency: 142, uptime: 99.98, req: 1093, version: 'v2.4.0', port: 8083 },
  { name: 'Notification Svc',  tag: 'notify',     status: 'Healthy',  latency: 67,  uptime: 99.99, req: 9812, version: 'v2.4.2', port: 8084 },
  { name: 'Auth Gateway',      tag: 'auth',       status: 'Healthy',  latency: 43,  uptime: 99.99, req: 14200,version: 'v2.4.1', port: 8085 },
  { name: 'Product Service',   tag: 'products',   status: 'Healthy',  latency: 115, uptime: 99.95, req: 3341, version: 'v2.3.9', port: 8086 },
];

const gatewayTraffic = [
  { time: '00:00', req: 320, err: 2, p99: 145 },
  { time: '04:00', req: 180, err: 1, p99: 98 },
  { time: '08:00', req: 890, err: 8, p99: 210 },
  { time: '10:00', req: 1420, err: 12, p99: 278 },
  { time: '12:00', req: 1980, err: 9, p99: 312 },
  { time: '14:00', req: 2210, err: 15, p99: 334 },
  { time: '16:00', req: 1870, err: 7, p99: 289 },
  { time: '18:00', req: 1540, err: 5, p99: 245 },
  { time: '20:00', req: 980, err: 3, p99: 178 },
  { time: '22:00', req: 540, err: 2, p99: 134 },
];

const logLines = [
  { ts: '09:42:31.124', level: 'ERROR', svc: 'inventory', msg: 'Stock sync timeout after 30000ms — WEP-001', trace: 'trace-8a2f' },
  { ts: '09:42:30.880', level: 'WARN',  svc: 'gateway',   msg: 'Rate limit threshold 80% reached — seller-id: 1042', trace: 'trace-7e1c' },
  { ts: '09:42:28.441', level: 'INFO',  svc: 'orders',    msg: 'Order ORD12345 state transition: pending → confirmed', trace: 'trace-6b9d' },
  { ts: '09:42:25.003', level: 'INFO',  svc: 'auth',      msg: 'JWT validated — seller@marketnest.com, scope: seller', trace: 'trace-5a3e' },
  { ts: '09:42:22.789', level: 'INFO',  svc: 'analytics', msg: 'Weekly report job started — period: Sep 13–19 2026', trace: 'trace-4d2b' },
  { ts: '09:42:20.001', level: 'ERROR', svc: 'inventory', msg: 'DB write failed: deadlock detected on products table', trace: 'trace-3f8a' },
  { ts: '09:42:18.553', level: 'INFO',  svc: 'notify',    msg: 'Push sent: order_confirmed to priya.sharma@gmail.com', trace: 'trace-2c7b' },
  { ts: '09:42:15.220', level: 'WARN',  svc: 'products',  msg: 'Cache miss rate >25% — consider warming product cache', trace: 'trace-1e6a' },
  { ts: '09:42:12.004', level: 'INFO',  svc: 'gateway',   msg: 'Health check passed — all 6 upstream services OK', trace: 'trace-0d4f' },
  { ts: '09:42:08.799', level: 'INFO',  svc: 'orders',    msg: 'Bulk export triggered — 356 records, format: CSV', trace: 'trace-9c3e' },
  { ts: '09:42:05.113', level: 'INFO',  svc: 'auth',      msg: 'Admin login: admin@marketnest.com — IP: 103.21.x.x', trace: 'trace-8b2d' },
  { ts: '09:42:01.441', level: 'WARN',  svc: 'analytics', msg: 'Slow query detected: revenue_rollup took 4.2s', trace: 'trace-7a1c' },
];

const sellerList = [
  { id: 'SEL-001', name: 'MarketNest Official', email: 'seller@marketnest.com', plan: 'Pro', status: 'Active', gmv: 245000, orders: 356, joined: 'Jan 2025' },
  { id: 'SEL-002', name: 'TechGadgets India',   email: 'tech@gadgets.in',       plan: 'Starter', status: 'Active', gmv: 98000, orders: 142, joined: 'Mar 2025' },
  { id: 'SEL-003', name: 'StyleHub Co.',        email: 'hello@stylehub.com',    plan: 'Pro', status: 'Suspended', gmv: 31000, orders: 67, joined: 'May 2025' },
  { id: 'SEL-004', name: 'GadgetZone PVT',      email: 'ops@gadgetzone.in',     plan: 'Enterprise', status: 'Active', gmv: 512000, orders: 891, joined: 'Nov 2024' },
  { id: 'SEL-005', name: 'QuickBuy Store',      email: 'admin@quickbuy.io',     plan: 'Starter', status: 'Active', gmv: 44000, orders: 98, joined: 'Jun 2025' },
];

const rbacRoles = [
  { role: 'Platform Admin', users: 2, permissions: ['All access', 'RBAC management', 'Billing', 'Seller suspend/ban'], color: '#EF4444' },
  { role: 'Operations Lead', users: 5, permissions: ['Seller management', 'Microservice logs', 'Gateway config'], color: '#F59E0B' },
  { role: 'Seller (Pro)',   users: 84, permissions: ['Products', 'Orders', 'Inventory', 'Analytics', 'Notifications'], color: '#6366F1' },
  { role: 'Seller (Starter)', users: 312, permissions: ['Products', 'Orders', 'Inventory'], color: '#3B82F6' },
  { role: 'Support Agent', users: 11, permissions: ['View orders', 'View customers', 'Read-only analytics'], color: '#8B5CF6' },
  { role: 'Auditor', users: 3, permissions: ['Read-only all', 'Export reports', 'View logs'], color: '#10B981' },
];

const platformAlerts = [
  { id: 1, severity: 'Critical', title: 'Inventory Service DB deadlock', detail: 'Concurrent write conflict on products table. Auto-retry in progress. Affecting WEP-001 stock sync.', svc: 'inventory', time: '3 min ago', resolved: false },
  { id: 2, severity: 'High', title: 'API Gateway rate limit at 80%', detail: 'Seller SEL-001 approaching request quota. Current: 14,200 / 18,000 req/hr. Consider upgrading plan.', svc: 'gateway', time: '8 min ago', resolved: false },
  { id: 3, severity: 'High', title: 'Inventory Service p99 latency spike', detail: 'P99 response time: 312ms (threshold: 250ms). Root cause: slow DB query on stock_levels join.', svc: 'inventory', time: '12 min ago', resolved: false },
  { id: 4, severity: 'Medium', title: 'Analytics slow query detected', detail: 'revenue_rollup aggregation took 4.2s. Recommend adding composite index on (seller_id, created_at).', svc: 'analytics', time: '18 min ago', resolved: true },
  { id: 5, severity: 'Low', title: 'Product cache miss rate elevated', detail: 'Cache miss rate at 28% (normal: <15%). Warming cache job scheduled for 10:00 AM.', svc: 'products', time: '25 min ago', resolved: true },
  { id: 6, severity: 'Info', title: 'Scheduled DB maintenance complete', detail: 'Nightly compaction finished in 4m 22s. No downtime. Next maintenance: 4 Oct 2026 02:00 AM.', svc: 'database', time: '6 hr ago', resolved: true },
];

// ── Admin nav ──────────────────────────────────────────────────────────────────
const adminNavItems: { id: AdminScreen; label: string; icon: React.ReactNode }[] = [
  { id: 'health',  label: 'SOA Health',      icon: <Activity size={15} /> },
  { id: 'logs',    label: 'Microservice Logs',icon: <Terminal size={15} /> },
  { id: 'gateway', label: 'API Gateway',      icon: <Globe size={15} /> },
  { id: 'sellers', label: 'Seller Management',icon: <Users size={15} /> },
  { id: 'rbac',    label: 'RBAC Permissions', icon: <Shield size={15} /> },
  { id: 'alerts',  label: 'Platform Alerts',  icon: <AlertCircle size={15} /> },
];

// ── Admin screens ──────────────────────────────────────────────────────────────
function HealthScreen() {
  const healthy = microservices.filter(m => m.status === 'Healthy').length;
  return (
    <div className="p-6 space-y-5">
      <div className="flex items-end justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-widest text-indigo-400 mb-1">Service Orchestration Architecture</p>
          <h1 className="text-xl font-bold text-white">SOA Service Health</h1>
          <p className="text-sm text-slate-500 mt-0.5">Real-time microservice status · 20 Sep 2026, 09:42 AM</p>
        </div>
        <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-500/20">
          <span className="w-2 h-2 rounded-full bg-emerald-400" style={{ boxShadow: '0 0 6px rgba(16,185,129,0.8)', animation: 'pulse 2s infinite' }} />
          {healthy}/6 Healthy
        </div>
      </div>

      {/* Summary strip */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Total Requests / hr', value: microservices.reduce((s,m) => s+m.req,0).toLocaleString(), color: '#6366F1' },
          { label: 'Avg Latency',         value: `${Math.round(microservices.reduce((s,m)=>s+m.latency,0)/microservices.length)}ms`, color: '#10B981' },
          { label: 'Degraded Services',   value: `${microservices.filter(m=>m.status==='Degraded').length}`, color: '#EF4444' },
        ].map(s => (
          <GlassCard key={s.label} className="px-5 py-4">
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-1">{s.label}</p>
            <p className="text-2xl font-black" style={{ color: s.color }}>{s.value}</p>
          </GlassCard>
        ))}
      </div>

      {/* Service cards grid */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {microservices.map(m => {
          const ok = m.status === 'Healthy';
          const statusColor = ok ? '#10B981' : '#EF4444';
          const latencyColor = m.latency < 150 ? '#10B981' : m.latency < 250 ? '#F59E0B' : '#EF4444';
          return (
            <GlassCard key={m.name} className="p-5">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xs font-black"
                    style={{ background: ok ? 'rgba(16,185,129,0.12)' : 'rgba(239,68,68,0.12)', color: statusColor, border: `1px solid ${statusColor}30` }}>
                    <Server size={16} />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-white">{m.name}</p>
                    <p className="text-[10px] font-mono text-slate-500">:{m.port} · {m.version}</p>
                  </div>
                </div>
                <StatusPill status={m.status} />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-lg px-3 py-2" style={{ background: 'rgba(15,20,35,0.5)' }}>
                  <p className="text-[9px] text-slate-600 uppercase font-bold mb-0.5">Latency</p>
                  <p className="text-sm font-black" style={{ color: latencyColor }}>{m.latency}ms</p>
                </div>
                <div className="rounded-lg px-3 py-2" style={{ background: 'rgba(15,20,35,0.5)' }}>
                  <p className="text-[9px] text-slate-600 uppercase font-bold mb-0.5">Uptime</p>
                  <p className="text-sm font-black text-emerald-400">{m.uptime}%</p>
                </div>
                <div className="rounded-lg px-3 py-2" style={{ background: 'rgba(15,20,35,0.5)' }}>
                  <p className="text-[9px] text-slate-600 uppercase font-bold mb-0.5">Req/hr</p>
                  <p className="text-sm font-black text-slate-300">{m.req.toLocaleString()}</p>
                </div>
              </div>
              {/* Latency bar */}
              <div className="mt-3">
                <div className="h-1 rounded-full overflow-hidden" style={{ background: 'rgba(51,65,85,0.5)' }}>
                  <div className="h-full rounded-full transition-all"
                    style={{ width: `${Math.min(100,(m.latency/400)*100)}%`, background: latencyColor, boxShadow: `0 0 6px ${latencyColor}60` }} />
                </div>
              </div>
            </GlassCard>
          );
        })}
      </div>
    </div>
  );
}

function LogsScreen() {
  const [filterLevel, setFilterLevel] = useState('ALL');
  const [filterSvc, setFilterSvc] = useState('all');
  const levels = ['ALL','INFO','WARN','ERROR'];
  const levelColor: Record<string,string> = { INFO:'text-blue-400', WARN:'text-amber-400', ERROR:'text-red-400' };
  const levelBg:    Record<string,string> = { INFO:'bg-blue-500/10 border-blue-500/25', WARN:'bg-amber-500/10 border-amber-500/25', ERROR:'bg-red-500/10 border-red-500/25' };
  const filtered = logLines.filter(l =>
    (filterLevel === 'ALL' || l.level === filterLevel) &&
    (filterSvc === 'all' || l.svc === filterSvc)
  );
  const svcs = ['all', ...Array.from(new Set(logLines.map(l => l.svc)))];

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-xl font-bold text-white">Microservice Logs</h1>
          <p className="text-sm text-slate-500 mt-0.5">Live aggregated log stream · last 60 min</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-slate-300 transition-all"
          style={{ background: 'rgba(30,41,59,0.6)', border: '1px solid rgba(51,65,85,0.7)' }}>
          <Download size={13} /> Export Logs
        </button>
      </div>

      <GlassCard className="p-4 flex flex-wrap gap-3">
        <div className="flex gap-1.5">
          {levels.map(l => (
            <button key={l} onClick={() => setFilterLevel(l)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${filterLevel === l ? 'text-white' : 'text-slate-500 hover:text-slate-300'}`}
              style={filterLevel === l ? { background: 'linear-gradient(135deg,#6366F1,#4F46E5)' } : { background: 'rgba(15,20,35,0.5)', border: '1px solid rgba(51,65,85,0.5)' }}>
              {l}
            </button>
          ))}
        </div>
        <select value={filterSvc} onChange={e => setFilterSvc(e.target.value)}
          className="text-xs rounded-lg px-3 py-1.5 text-slate-300 outline-none"
          style={{ background: 'rgba(15,20,35,0.7)', border: '1px solid rgba(51,65,85,0.6)' }}>
          {svcs.map(s => <option key={s} value={s}>{s === 'all' ? 'All Services' : s}</option>)}
        </select>
        <span className="ml-auto text-xs text-slate-600 self-center">{filtered.length} entries</span>
      </GlassCard>

      <GlassCard className="overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-700/40 flex items-center gap-2"
          style={{ background: 'rgba(15,20,35,0.5)' }}>
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-[10px] font-mono text-slate-500">LIVE · platform-log-aggregator · stdout</span>
        </div>
        <div className="font-mono text-xs divide-y divide-slate-800/40 max-h-[60vh] overflow-y-auto">
          {filtered.map((l, i) => (
            <div key={i} className="flex items-start gap-4 px-4 py-2.5 hover:bg-slate-800/30 transition-colors group">
              <span className="text-slate-700 text-[10px] flex-shrink-0 pt-0.5">{l.ts}</span>
              <span className={`text-[10px] font-black px-1.5 py-0.5 rounded border flex-shrink-0 ${levelBg[l.level] || ''} ${levelColor[l.level] || 'text-slate-400'}`}>
                {l.level}
              </span>
              <span className="text-indigo-400/70 text-[10px] w-20 flex-shrink-0 pt-0.5 truncate">[{l.svc}]</span>
              <span className="text-slate-300 flex-1 leading-relaxed">{l.msg}</span>
              <span className="text-slate-700 text-[9px] opacity-0 group-hover:opacity-100 transition-opacity pt-0.5">{l.trace}</span>
            </div>
          ))}
          {filtered.length === 0 && <div className="py-16 text-center text-slate-600">No log entries match filter.</div>}
        </div>
      </GlassCard>
    </div>
  );
}

function GatewayScreen() {
  const totalReq = gatewayTraffic.reduce((s,t)=>s+t.req,0);
  const totalErr = gatewayTraffic.reduce((s,t)=>s+t.err,0);
  const errRate  = ((totalErr/totalReq)*100).toFixed(2);

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-xl font-bold text-white">API Gateway Traffic</h1>
          <p className="text-sm text-slate-500 mt-0.5">Request volume, error rate &amp; latency · 20 Sep 2026</p>
        </div>
        <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-500/20">
          <Globe size={12} /> Gateway v2.4 · Online
        </div>
      </div>

      <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
        {[
          { label: 'Total Requests', value: totalReq.toLocaleString(), color: '#6366F1' },
          { label: 'Error Count',    value: totalErr.toString(), color: '#EF4444' },
          { label: 'Error Rate',     value: `${errRate}%`, color: '#F59E0B' },
          { label: 'Peak P99',       value: '334ms', color: '#10B981' },
        ].map(k => (
          <GlassCard key={k.label} className="px-4 py-3.5">
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-1">{k.label}</p>
            <p className="text-xl font-black" style={{ color: k.color }}>{k.value}</p>
          </GlassCard>
        ))}
      </div>

      <GlassCard className="p-5">
        <h2 className="text-sm font-bold text-white mb-0.5">Request Volume vs Error Count</h2>
        <p className="text-xs text-slate-500 mb-5">Hourly breakdown · 00:00 – 22:00</p>
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={gatewayTraffic}>
            <defs>
              <linearGradient id="gReq" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366F1" stopOpacity={0.4}/>
                <stop offset="95%" stopColor="#6366F1" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(51,65,85,0.4)" />
            <XAxis dataKey="time" tick={{ fontSize:10, fill:'#475569' }} axisLine={false} tickLine={false}/>
            <YAxis tick={{ fontSize:10, fill:'#475569' }} axisLine={false} tickLine={false}/>
            <Tooltip content={<DarkTooltip />} />
            <Legend iconType="circle" iconSize={7} wrapperStyle={{ fontSize:11, color:'#64748B' }} />
            <Area type="monotone" dataKey="req" name="Requests" stroke="#6366F1" strokeWidth={2} fill="url(#gReq)" dot={false}/>
            <Area type="monotone" dataKey="err" name="Errors" stroke="#EF4444" strokeWidth={2} fill="rgba(239,68,68,0.1)" dot={false}/>
          </AreaChart>
        </ResponsiveContainer>
      </GlassCard>

      <GlassCard className="p-5">
        <h2 className="text-sm font-bold text-white mb-0.5">P99 Latency Trend</h2>
        <p className="text-xs text-slate-500 mb-5">99th percentile response time (ms)</p>
        <ResponsiveContainer width="100%" height={160}>
          <LineChart data={gatewayTraffic}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(51,65,85,0.4)" />
            <XAxis dataKey="time" tick={{ fontSize:10, fill:'#475569' }} axisLine={false} tickLine={false}/>
            <YAxis tick={{ fontSize:10, fill:'#475569' }} axisLine={false} tickLine={false} unit="ms"/>
            <Tooltip content={<DarkTooltip />} />
            <Line type="monotone" dataKey="p99" name="P99 Latency" stroke="#10B981" strokeWidth={2.5}
              dot={{ r:3, fill:'#10B981', strokeWidth:0 }} style={{ filter:'drop-shadow(0 0 4px rgba(16,185,129,0.5))' }} />
          </LineChart>
        </ResponsiveContainer>
      </GlassCard>
    </div>
  );
}

function SellersScreen() {
  const [search, setSearch] = useState('');
  const filtered = sellerList.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase()) || s.id.toLowerCase().includes(search.toLowerCase())
  );
  const planColors: Record<string,string> = { Pro:'text-indigo-400', Starter:'text-slate-400', Enterprise:'text-amber-400' };

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-xl font-bold text-white">Seller Management</h1>
          <p className="text-sm text-slate-500 mt-0.5">{sellerList.length} registered sellers on platform</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-white transition-all"
          style={{ background: 'linear-gradient(135deg,#6366F1,#4F46E5)', boxShadow: '0 0 20px rgba(99,102,241,0.3)' }}>
          <UserPlus size={14} /> Onboard Seller
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Active Sellers', value: sellerList.filter(s=>s.status==='Active').length.toString(), color:'#10B981' },
          { label: 'Platform GMV', value:`₹${(sellerList.reduce((s,x)=>s+x.gmv,0)/1000).toFixed(0)}K`, color:'#6366F1' },
          { label: 'Suspended', value: sellerList.filter(s=>s.status==='Suspended').length.toString(), color:'#EF4444' },
        ].map(k => (
          <GlassCard key={k.label} className="px-4 py-3.5">
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-1">{k.label}</p>
            <p className="text-xl font-black" style={{ color: k.color }}>{k.value}</p>
          </GlassCard>
        ))}
      </div>

      <GlassCard>
        <div className="p-4 border-b border-slate-700/50">
          <div className="max-w-sm">
            <GlassInput value={search} onChange={setSearch} placeholder="Search by name or ID..." />
          </div>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-700/40">
              {['Seller ID','Store Name','Email','Plan','Status','GMV','Orders','Joined','Actions'].map(h => (
                <th key={h} className="text-left px-4 py-3.5 text-[10px] font-black text-slate-500 uppercase tracking-widest">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((s, i) => (
              <tr key={s.id}
                className={`border-b border-slate-800/40 transition-all ${i===filtered.length-1?'border-0':''}`}
                style={{ background:'transparent' }}
                onMouseEnter={e=>(e.currentTarget.style.background='rgba(99,102,241,0.04)')}
                onMouseLeave={e=>(e.currentTarget.style.background='transparent')}>
                <td className="px-4 py-3.5 font-mono text-xs text-indigo-400">{s.id}</td>
                <td className="px-4 py-3.5 font-semibold text-slate-200">{s.name}</td>
                <td className="px-4 py-3.5 text-slate-500 text-xs">{s.email}</td>
                <td className="px-4 py-3.5"><span className={`text-xs font-bold ${planColors[s.plan]}`}>{s.plan}</span></td>
                <td className="px-4 py-3.5"><StatusPill status={s.status === 'Suspended' ? 'Inactive' : 'Active'} /></td>
                <td className="px-4 py-3.5 font-black text-emerald-400">₹{s.gmv.toLocaleString('en-IN')}</td>
                <td className="px-4 py-3.5 text-slate-300 font-semibold">{s.orders}</td>
                <td className="px-4 py-3.5 text-slate-500 text-xs">{s.joined}</td>
                <td className="px-4 py-3.5">
                  <div className="flex gap-1">
                    <button className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-400 transition-colors"
                      style={{ background:'rgba(99,102,241,0.08)' }}><Eye size={12}/></button>
                    <button className="p-1.5 rounded-lg text-slate-500 hover:text-amber-400 transition-colors"
                      style={{ background:'rgba(245,158,11,0.08)' }}><Edit2 size={12}/></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </GlassCard>
    </div>
  );
}

function RBACScreen() {
  return (
    <div className="p-6 space-y-5">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-xl font-bold text-white">RBAC Permissions</h1>
          <p className="text-sm text-slate-500 mt-0.5">Role-based access control matrix — MarketNest Platform</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-white transition-all"
          style={{ background: 'linear-gradient(135deg,#6366F1,#4F46E5)', boxShadow: '0 0 20px rgba(99,102,241,0.3)' }}>
          <Plus size={14} /> Add Role
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {rbacRoles.map(r => (
          <GlassCard key={r.role} className="p-5">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ background: `${r.color}18`, border: `1px solid ${r.color}30`, color: r.color }}>
                  <Shield size={15} />
                </div>
                <div>
                  <p className="text-sm font-bold text-white">{r.role}</p>
                  <p className="text-[10px] text-slate-500">{r.users} user{r.users!==1?'s':''}</p>
                </div>
              </div>
              <button className="text-xs text-slate-600 hover:text-slate-400 transition-colors"><Edit2 size={12}/></button>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {r.permissions.map(p => (
                <span key={p} className="text-[10px] px-2 py-1 rounded-lg font-semibold"
                  style={{ background:`${r.color}10`, color: r.color, border:`1px solid ${r.color}25` }}>
                  {p}
                </span>
              ))}
            </div>
          </GlassCard>
        ))}
      </div>

      {/* Access matrix */}
      <GlassCard className="p-5">
        <h2 className="text-sm font-bold text-white mb-4">Quick Access Matrix</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-700/40">
                <th className="text-left py-2 pr-4 text-[10px] font-black text-slate-500 uppercase tracking-widest">Permission</th>
                {rbacRoles.map(r => (
                  <th key={r.role} className="text-center py-2 px-3 text-[10px] font-black uppercase tracking-widest" style={{ color: r.color }}>{r.role.split(' ')[0]}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {['Products','Orders','Inventory','Analytics','Seller Mgmt','Logs','Gateway','RBAC','Billing'].map(perm => (
                <tr key={perm} className="border-b border-slate-800/30">
                  <td className="py-2.5 pr-4 text-slate-400 font-medium">{perm}</td>
                  {rbacRoles.map(r => {
                    const has = r.role === 'Platform Admin' ||
                      (r.permissions.some(p => p.toLowerCase().includes(perm.toLowerCase()) || p === 'All access' || p.includes('all')));
                    return (
                      <td key={r.role} className="text-center py-2.5 px-3">
                        {has
                          ? <span className="text-emerald-400" style={{ filter:'drop-shadow(0 0 4px rgba(16,185,129,0.6))' }}>✓</span>
                          : <span className="text-slate-700">—</span>}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
}

function PlatformAlertsScreen() {
  const [filter, setFilter] = useState('All');
  const filters = ['All', 'Active', 'Resolved'];
  const sevColors: Record<string,{ border:string; bg:string; text:string; dot:string }> = {
    Critical: { border:'border-l-red-500',    bg:'bg-red-500/6',    text:'text-red-400',    dot:'bg-red-500' },
    High:     { border:'border-l-amber-500',  bg:'bg-amber-500/5',  text:'text-amber-400',  dot:'bg-amber-500' },
    Medium:   { border:'border-l-yellow-500', bg:'bg-yellow-500/4', text:'text-yellow-400', dot:'bg-yellow-500' },
    Low:      { border:'border-l-blue-500',   bg:'bg-blue-500/4',   text:'text-blue-400',   dot:'bg-blue-500' },
    Info:     { border:'border-l-slate-500',  bg:'bg-slate-500/4',  text:'text-slate-400',  dot:'bg-slate-500' },
  };
  const filtered = platformAlerts.filter(a =>
    filter === 'All' || (filter === 'Active' ? !a.resolved : a.resolved)
  );

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-xl font-bold text-white">Platform Alerts</h1>
          <p className="text-sm text-slate-500 mt-0.5">{platformAlerts.filter(a=>!a.resolved).length} active · {platformAlerts.filter(a=>a.resolved).length} resolved</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium text-slate-300 transition-all"
          style={{ background:'rgba(30,41,59,0.6)', border:'1px solid rgba(51,65,85,0.7)' }}>
          <Check size={13} /> Resolve All
        </button>
      </div>

      {/* Severity summary */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
        {(['Critical','High','Medium','Low'] as const).map(sev => {
          const cnt = platformAlerts.filter(a=>a.severity===sev&&!a.resolved).length;
          const c = sevColors[sev];
          return (
            <GlassCard key={sev} className="flex items-center gap-3 px-4 py-3.5">
              <span className={`w-3 h-3 rounded-full flex-shrink-0 ${c.dot}`} style={{ boxShadow: cnt>0?`0 0 8px currentColor`:'' }} />
              <span className="text-sm text-slate-400">{sev}</span>
              <span className={`ml-auto text-xl font-black ${cnt>0?c.text:'text-slate-600'}`}>{cnt}</span>
            </GlassCard>
          );
        })}
      </div>

      {/* Filter */}
      <div className="flex gap-2">
        {filters.map(f => (
          <button key={f} onClick={()=>setFilter(f)}
            className={`px-4 py-2 rounded-full text-xs font-bold transition-all ${filter===f?'text-white':'text-slate-400 hover:text-slate-200'}`}
            style={filter===f?{background:'linear-gradient(135deg,#6366F1,#4F46E5)',boxShadow:'0 0 14px rgba(99,102,241,0.35)'}:{background:'rgba(30,41,59,0.5)',border:'1px solid rgba(51,65,85,0.6)'}}>
            {f}
          </button>
        ))}
      </div>

      <GlassCard className="overflow-hidden divide-y divide-slate-800/50">
        {filtered.map(a => {
          const c = sevColors[a.severity] || sevColors.Info;
          return (
            <div key={a.id} className={`flex items-start gap-5 p-5 border-l-[3px] ${c.border} ${c.bg} transition-all hover:bg-slate-800/20 ${a.resolved?'opacity-60':''}`}>
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${c.text}`}
                style={{ background:`rgba(15,20,35,0.5)`, border:`1px solid rgba(148,163,184,0.1)` }}>
                {a.resolved ? <CheckCircle2 size={15}/> : <AlertCircle size={15}/>}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2 mb-1.5">
                  <span className={`text-[9px] font-black uppercase tracking-widest border rounded px-1.5 py-0.5 ${c.text}`}
                    style={{ borderColor:'currentColor', opacity:0.8 }}>
                    {a.severity}
                  </span>
                  <span className="text-[9px] font-black uppercase tracking-widest text-indigo-400/70 bg-indigo-500/8 px-1.5 py-0.5 rounded border border-indigo-500/15">
                    [{a.svc}]
                  </span>
                  {a.resolved && <span className="text-[10px] text-emerald-400 font-semibold">✓ Resolved</span>}
                </div>
                <p className={`text-sm font-bold mb-1 ${a.resolved?'text-slate-400':'text-white'}`}>{a.title}</p>
                <p className="text-xs text-slate-500 leading-relaxed">{a.detail}</p>
                <p className="text-[10px] text-slate-600 mt-2">{a.time}</p>
              </div>
              {!a.resolved && (
                <button className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-xl font-semibold text-indigo-400 transition-all flex-shrink-0"
                  style={{ background:'rgba(99,102,241,0.1)', border:'1px solid rgba(99,102,241,0.25)' }}>
                  <Check size={11}/> Resolve
                </button>
              )}
            </div>
          );
        })}
        {filtered.length===0 && <div className="py-16 text-center text-sm text-slate-600">No alerts in this category.</div>}
      </GlassCard>
    </div>
  );
}

// ── AdminApp shell ─────────────────────────────────────────────────────────────
function AdminApp({ onLogout }: { onLogout: () => void }) {
  const [screen, setScreen] = useState<AdminScreen>('health');
  const activeAlerts = platformAlerts.filter(a => !a.resolved).length;

  const screenMap: Record<AdminScreen, React.ReactNode> = {
    health:  <HealthScreen />,
    logs:    <LogsScreen />,
    gateway: <GatewayScreen />,
    sellers: <SellersScreen />,
    rbac:    <RBACScreen />,
    alerts:  <PlatformAlertsScreen />,
  };

  return (
    <div className="flex h-screen overflow-hidden bg-mesh font-sans">
      {/* Sidebar */}
      <aside className="w-56 flex-shrink-0 flex flex-col"
        style={{ background: 'rgba(8,12,20,0.97)', borderRight: '1px solid rgba(51,65,85,0.5)' }}>
        {/* Logo */}
        <div className="px-5 py-5" style={{ borderBottom: '1px solid rgba(51,65,85,0.4)' }}>
          <div className="flex items-center gap-3">
            <MarketNestLogo size={36} />
            <div>
              <p className="text-sm font-black text-white leading-tight">MarketNest</p>
              <p className="text-[9px] font-bold tracking-[0.15em] uppercase mt-0.5"
                style={{ background: 'linear-gradient(90deg,#EF4444,#F59E0B)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                Admin Console
              </p>
            </div>
          </div>
        </div>

        {/* Role indicator */}
        <div className="mx-3 mt-3 px-3 py-2.5 rounded-xl"
          style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)' }}>
          <div className="flex items-center gap-2">
            <Shield size={12} className="text-red-400 flex-shrink-0" />
            <div>
              <p className="text-[10px] font-black text-red-400 uppercase tracking-wider">Platform Admin</p>
              <p className="text-[9px] text-slate-600">admin@marketnest.com</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 px-3 space-y-0.5 overflow-y-auto scrollbar-hide">
          <p className="px-2 pb-2 text-[8px] font-black text-slate-700 uppercase tracking-[0.18em]">Admin Console</p>
          {adminNavItems.map(item => {
            const active = screen === item.id;
            return (
              <button key={item.id} onClick={() => setScreen(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all group ${active ? 'text-red-300' : 'text-slate-500 hover:text-slate-200 hover:bg-white/5'}`}
                style={active ? { background: 'linear-gradient(135deg,rgba(239,68,68,0.18),rgba(239,68,68,0.08))', border: '1px solid rgba(239,68,68,0.22)', boxShadow: '0 0 12px rgba(239,68,68,0.1)' } : {}}>
                <span className={`flex-shrink-0 transition-colors ${active ? 'text-red-400' : 'text-slate-600 group-hover:text-slate-400'}`}>{item.icon}</span>
                <span>{item.label}</span>
                {item.id === 'alerts' && activeAlerts > 0 && (
                  <span className="ml-auto min-w-[18px] h-[18px] rounded-full bg-red-500 text-white text-[9px] font-black flex items-center justify-center px-1 flex-shrink-0"
                    style={{ boxShadow: '0 0 8px rgba(239,68,68,0.6)' }}>
                    {activeAlerts}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Logout */}
        <div className="p-3" style={{ borderTop: '1px solid rgba(51,65,85,0.4)' }}>
          <button onClick={onLogout} className="w-full flex items-center gap-2.5 px-2.5 py-2.5 rounded-xl hover:bg-red-500/8 cursor-pointer transition-all group">
            <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-black text-red-300 flex-shrink-0"
              style={{ background: 'rgba(239,68,68,0.2)', border: '1px solid rgba(239,68,68,0.3)' }}>A</div>
            <div className="flex-1 min-w-0 text-left">
              <p className="text-xs font-bold text-slate-300 leading-none">Admin Account</p>
              <p className="text-[9px] text-slate-600 mt-0.5 truncate">admin@marketnest.com</p>
            </div>
            <LogOut size={12} className="text-slate-700 group-hover:text-red-400 flex-shrink-0 transition-colors" />
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="flex-shrink-0 h-14 flex items-center px-5 gap-4"
          style={{ background: 'rgba(8,12,20,0.85)', borderBottom: '1px solid rgba(51,65,85,0.5)' }}>
          <div className="flex items-center gap-2">
            <Shield size={14} className="text-red-400" />
            <span className="text-sm font-bold text-slate-300">Admin Console</span>
            <span className="text-slate-700 mx-1">/</span>
            <span className="text-sm text-slate-500 capitalize">{adminNavItems.find(n=>n.id===screen)?.label}</span>
          </div>
          <div className="ml-auto flex items-center gap-3">
            {/* All microservices health pulse */}
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold"
              style={{ background:'rgba(239,68,68,0.08)', border:'1px solid rgba(239,68,68,0.2)', color:'#F87171' }}>
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 flex-shrink-0 animate-pulse" />
              {microservices.filter(m=>m.status==='Degraded').length} Degraded · {microservices.filter(m=>m.status==='Healthy').length} Healthy
            </div>
            <button onClick={onLogout}
              className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-red-400 transition-all"
              style={{ background:'rgba(239,68,68,0.08)', border:'1px solid rgba(239,68,68,0.2)' }}>
              <LogOut size={12} /> Sign Out
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto">
          {screenMap[screen]}
        </main>
      </div>
    </div>
  );
}

// ROOT — auth router
export default function App() {
  const [auth, setAuth] = useState<'login' | 'seller' | 'admin'>('login');

  if (auth === 'seller') return <SellerApp onLogout={() => setAuth('login')} />;
  if (auth === 'admin')  return <AdminApp  onLogout={() => setAuth('login')} />;
  return <LoginPage onLogin={role => setAuth(role)} />;
}
